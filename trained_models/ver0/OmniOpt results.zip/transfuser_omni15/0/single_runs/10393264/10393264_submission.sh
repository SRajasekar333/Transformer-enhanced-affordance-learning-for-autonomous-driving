#!/bin/bash

# Parameters
#SBATCH --cpus-per-task=4
#SBATCH --error=/data/horse/ws/rasa397c-Sankar/Multimodal/transfuser/model_ckpt/omniopt/omniopt_1/ax/runs/transfuser_omni15/0/single_runs/%j/%j_0_log.err
#SBATCH --gres=gpu:0
#SBATCH --job-name=transfuser_omni15_c5f942cb-670c-4129-891e-678d0d3a8478
#SBATCH --mem=1GB
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --open-mode=append
#SBATCH --output=/data/horse/ws/rasa397c-Sankar/Multimodal/transfuser/model_ckpt/omniopt/omniopt_1/ax/runs/transfuser_omni15/0/single_runs/%j/%j_0_log.out
#SBATCH --signal=USR2@0
#SBATCH --time=600
#SBATCH --wckey=submitit

# command
export SUBMITIT_EXECUTOR=slurm
/data/horse/ws/rasa397c-Sankar/Multimodal/transfuser/model_ckpt/venv/.omniax_x86_64_Python_3.10.4_barnard/bin/python3 -u -m submitit.core._submit /data/horse/ws/rasa397c-Sankar/Multimodal/transfuser/model_ckpt/omniopt/omniopt_1/ax/runs/transfuser_omni15/0/single_runs/%j
