import argparse
import os
import datetime

from tqdm import tqdm
import numpy as np
import json
from PIL import Image, ImageDraw
import torch
from torch.utils.data import DataLoader

from config1 import GlobalConfig
from model import LidarCenterNet
from data import CARLA_Data

torch.cuda.empty_cache()

parser = argparse.ArgumentParser()
parser.add_argument('--root_dir', type=str, default=r'/data/horse/ws/rasa397c-Sankar/transfuser/data_mini', help='Root directory of your training data')
parser.add_argument('--model_path', type=str, required=True, help='path to model ckpt')
parser.add_argument('--args_path', type=str, required=True, help='path to training arguments')
parser.add_argument('--device', type=str, default='cuda', help='Device to use')
parser.add_argument('--batch_size', type=int, default=8, help='Batch size')
parser.add_argument('--save_path', type=str, default=None, help='path to save visualizations')
parser.add_argument('--total_size', type=int, default=100000, help='total images for which to generate visualizations')
parser.add_argument('--attn_thres', type=int, default=1, help='minimum # tokens of other modality required for global context')
# parser.add_argument('--backbone', type=str, default='transFuser', help='Which vision backbone to use. Options: geometric_fusion, transFuser, late_fusion, aim')
parser.add_argument('--setting', type=str, default='viz', help='What training setting to use. Options: '
                                                                   'all: Train on all towns no validation data. '
                                                                   '02_05_withheld: Do not train on Town 02 and Town 05. Use the data as validation data.')

args = parser.parse_args()

with open(args.args_path, 'r') as f:
	training_args = json.load(f)

# Config
#config = GlobalConfig()
config = GlobalConfig(root_dir=args.root_dir, setting=args.setting)
config.use_target_point_image = bool(training_args['use_target_point_image'])
config.n_layer = training_args['n_layer']

if args.save_path is not None and not os.path.isdir(args.save_path):
	os.makedirs(args.save_path, exist_ok=True)

# Data
viz_data = CARLA_Data(root=config.viz_data, config=config)
dataloader_viz = DataLoader(viz_data, batch_size=args.batch_size, shuffle=True, num_workers=8, pin_memory=False)

# Model
model = LidarCenterNet(config, args.device, training_args['backbone'], training_args['image_architecture'],training_args['lidar_architecture'], bool(training_args['use_velocity']))
model = torch.nn.DataParallel(model) # change to distributed data parallel later

model_parameters = filter(lambda p: p.requires_grad, model.parameters())
params = sum([np.prod(p.size()) for p in model_parameters])
print ('Total parameters: ', params)

#model.load_state_dict(torch.load(os.path.join(args.model_path, 'model_seed3_37.pth')))
#model.load_state_dict(torch.load(os.path.join(args.model_path), map_location=args.device))
#model.load_state_dict(torch.load(args.model_path))


# Load the state dictionary
state_dict = torch.load(os.path.join(args.model_path), map_location=args.device)
model.load_state_dict(state_dict, strict=False)
model.cuda()

'''
# Add the "module." prefix to the state_dict keys if not present
new_state_dict = {}
for k, v in state_dict.items():
    if not k.startswith('module.'):
        new_state_dict[f'module.{k}'] = v  # Add "module." prefix
    else:
        new_state_dict[k] = v

model.load_state_dict(new_state_dict)
'''
model.eval()

# patch_centers = []
# for i in range(16, 160, 32): # patch centers for image tokens
# 	for j in range(16, 704, 32):
# 		patch_centers.append((i,j))
# for i in range(16, 256, 32): # patch centers for lidar tokens
# 	for j in range(16, 256, 32):
# 		patch_centers.append((i,j))

# for PIL ImageDraw
patch_origins = []
for i in range(0, 160, 32): # patch origins for image tokens
	for j in range(0, 704, 32):
		patch_origins.append((j,i))
for i in range(0, 256, 32): # patch origins for lidar tokens
	for j in range(0, 256, 32):
		patch_origins.append((j,i))

cnt = 0

# central tokens in both modalities
central_image_tokens = list(range(22,88))
central_lidar_tokens = list(range(110+24,110+48))
# central_image_tokens = list(range(110))
# central_lidar_tokens = list(range(110,174))
image_global_context = [[], [], [], []]
lidar_global_context = [[], [], [], []]

with torch.no_grad():
	for enum, data in enumerate(tqdm(dataloader_viz)):
		if enum*args.batch_size >= args.total_size: # total images for which to generate visualizations
			break

		# create batch and move to GPU
		rgb = data['rgb'].to(args.device, dtype=torch.float32)
		lidar = data['lidar'].to(args.device, dtype=torch.float32)
        #target_point = data['target_point'].to(args.device, dtype=torch.float32)
		target_point_image = data['target_point_image'].to(args.device, dtype=torch.float32)
		ego_vel = data['speed'].to(args.device, dtype=torch.float32).reshape(-1, 1)
        _, _, fused_features = model.module._model(rgb, lidar, ego_vel)

feature_path = os.path.join(args.save_path, f'batch_{enum}_sample_{idx}.pt')
torch.save(fused_features[idx].cpu(), feature_path)
total_images_processed += fused_features.size(0)
'''
print(f'Total images processed: {total_images_processed}')
        for idx in range(fused_features.size(0)):
            feature_path = os.path.join(args.save_path, f'batch_{enum}_sample_{idx}.pt')
            torch.save(fused_features[idx].cpu(), feature_path)
        total_images_processed += fused_features.size(0)
'''
print(f'Total images processed: {total_images_processed}')
'''
		# get geometric projections to visualize geometric fusion
		bev_points = data['bev_points'][-1].numpy().astype(np.uint8)
		cam_points = data['cam_points'][-1].numpy().astype(np.uint8)
		bs, _, _, n_corres, p_dim = bev_points.shape
		bev_points = bev_points.reshape((bs, -1, n_corres, p_dim))
		cam_points = cam_points.reshape((bs, -1, n_corres, p_dim))
		gf_points = np.concatenate([cam_points, bev_points], axis=1)
		
		bev_to_cam_tokens = (bev_points[...,1]*22 + bev_points[...,0])
		cam_to_bev_tokens = 110 + (cam_points[...,1]*8 + cam_points[...,0])
		gf_projected_tokens = np.concatenate([cam_to_bev_tokens, bev_to_cam_tokens], axis=1)
		
		# forward pass for transfuser
		if config.use_target_point_image:
			lidar = torch.cat((lidar, target_point_image), dim=1)
'''			
		#_, _, fused_features = model.module._model(rgb, lidar, ego_vel)



            
torch.cuda.empty_cache()
        #_, _, _, attn_map = model.module._model(rgb, lidar, ego_vel)
'''		
		# we use 4 transformers in the model
		attn_map1 = attn_map[:,0,:,:,:].detach().cpu().numpy()
		attn_map2 = attn_map[:,1,:,:,:].detach().cpu().numpy()
		attn_map3 = attn_map[:,2,:,:,:].detach().cpu().numpy()
		attn_map4 = attn_map[:,3,:,:,:].detach().cpu().numpy()
		
		bz = rgb.shape[0]
		for idx in range(bz):
			img = np.transpose(data['rgb'][idx].numpy(), (1,2,0))
			lidar_full = (data['lidar_full'][idx].repeat(3,1,1).permute(1,2,0).numpy()*255).astype(np.uint8)
			
			if args.save_path is not None:
				img_path = os.path.join(args.save_path, str(cnt).zfill(5))
				if not os.path.isdir(img_path):
					os.makedirs(img_path, exist_ok=True)
				Image.fromarray(img).save(os.path.join(img_path, 'input_image.png'))
				Image.fromarray(lidar_full).save(os.path.join(img_path, 'input_lidar.png'))
				
			cnt += 1

			# visualize geometric fusion tokens
			if args.save_path is not None:
				for token in (central_image_tokens + central_lidar_tokens):
					gf_projected_indices = gf_projected_tokens[idx, token]
					gf_path = os.path.join(img_path, str(token)+'__gf'+'_'+'_'.join(str(xx) for xx in gf_projected_indices))
					if not os.path.isdir(gf_path):
						os.makedirs(gf_path, exist_ok=True)
					img_pil = Image.fromarray(img)
					img_draw = ImageDraw.Draw(img_pil)
					lidar_pil = Image.fromarray(lidar_full)
					lidar_draw = ImageDraw.Draw(lidar_pil)
					for attn_token in gf_projected_indices:
						if attn_token == 0 or attn_token == 110: continue # 0 tokens in both modalities are used as redundant placeholders
						if attn_token >= 110:
							lidar_draw.rectangle((patch_origins[attn_token], (patch_origins[attn_token][0]+32, patch_origins[attn_token][1]+32)), 
												fill=None, outline=(0,255,0), width=2)
						else:
							img_draw.rectangle((patch_origins[attn_token], (patch_origins[attn_token][0]+32, patch_origins[attn_token][1]+32)), 
												fill=None, outline=(0,255,0), width=2)
						
					if token >= 110:
						img_pil.save(os.path.join(gf_path, 'attended_token_img.png'))
					else:
						lidar_pil.save(os.path.join(gf_path, 'attended_token_lidar.png'))
			
			# visualize transfuser tokens
			for head in range(4):
				curr_attn = attn_map4[idx,head]
				for token in (central_image_tokens + central_lidar_tokens):
					attn_vector = curr_attn[token]
					attn_indices = np.argsort(attn_vector)[-5:]
					
					if token in central_image_tokens:
						cross_attn = np.sum(attn_indices>=110) >= args.attn_thres 
						image_global_context[head].append(cross_attn)
					else: 
						cross_attn = np.sum(attn_indices<110) >= args.attn_thres
						lidar_global_context[head].append(cross_attn)

					# save top 5 attended tokens for query tokens
					if args.save_path is not None:
						curr_path = os.path.join(img_path, str(token)+'_'+str(head)+'_'+'_'.join(str(xx) for xx in attn_indices))
						if not os.path.isdir(curr_path):
							os.makedirs(curr_path, exist_ok=True)
						
						# save source token
						if token < 110:
							img_pil = Image.fromarray(img)
							img_draw = ImageDraw.Draw(img_pil)
							img_draw.rectangle((patch_origins[token], (patch_origins[token][0]+32, patch_origins[token][1]+32)), 
												fill=None, outline=(255,0,0), width=2)
							img_pil.save(os.path.join(curr_path, 'source_token_img.png'))
						else:
							lidar_pil = Image.fromarray(lidar_full)
							lidar_draw = ImageDraw.Draw(lidar_pil)
							lidar_draw.rectangle((patch_origins[token], (patch_origins[token][0]+32, patch_origins[token][1]+32)), 
												fill=None, outline=(255,0,0), width=2)
							lidar_pil.save(os.path.join(curr_path, 'source_token_lidar.png'))

						# save transfuser attended tokens
						img_pil = Image.fromarray(img)
						img_draw = ImageDraw.Draw(img_pil)
						lidar_pil = Image.fromarray(lidar_full)
						lidar_draw = ImageDraw.Draw(lidar_pil)
						for attn_token in attn_indices:
							if attn_token >= 110:
								lidar_draw.rectangle((patch_origins[attn_token], (patch_origins[attn_token][0]+32, patch_origins[attn_token][1]+32)), 
													fill=None, outline=(0,255,0), width=2)
							else:
								img_draw.rectangle((patch_origins[attn_token], (patch_origins[attn_token][0]+32, patch_origins[attn_token][1]+32)), 
													fill=None, outline=(0,255,0), width=2)

						img_pil.save(os.path.join(curr_path, 'attended_token_img.png'))
						lidar_pil.save(os.path.join(curr_path, 'attended_token_lidar.png'))
			# exit()

# cross-modal attention for image tokens
image_global_context = np.array(image_global_context)
print (image_global_context.shape)
for head in range(config.n_head):
	curr_global_context = image_global_context[head]
	curr_global_context = curr_global_context>0
	valid_tokens = curr_global_context.sum()
	valid_percent = valid_tokens/len(curr_global_context)
	print ('for image tokens in head: ', head, curr_global_context.sum(), len(curr_global_context), valid_percent)

# cross-modal attention for lidar tokens
lidar_global_context = np.array(lidar_global_context)
print (lidar_global_context.shape)
for head in range(config.n_head):
	curr_global_context = lidar_global_context[head]
	curr_global_context = curr_global_context>0
	valid_tokens = curr_global_context.sum()
	valid_percent = valid_tokens/len(curr_global_context)
	print ('for lidar tokens in head: ', head, curr_global_context.sum(), len(curr_global_context), valid_percent)
 '''