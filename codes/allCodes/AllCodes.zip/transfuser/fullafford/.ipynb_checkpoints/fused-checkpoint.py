import argparse
import os
from tqdm import tqdm

import numpy as np
import torch
from torch.utils.data import DataLoader
torch.backends.cudnn.benchmark = True

from config1 import GlobalConfig
from model import LidarCenterNet
from data import CARLA_Data

parser = argparse.ArgumentParser()
parser.add_argument('--root_dir', type=str, default=r'/data/horse/ws/rasa397c-Sankar/transfuser/data_mini', help='Root directory of your training data')
parser.add_argument('--model_path', type=str, required=True, help='path to model ckpt')
parser.add_argument('--device', type=str, default='cuda', help='Device to use')
parser.add_argument('--batch_size', type=int, default=100, help='Batch size')
parser.add_argument('--total_size', type=int, default=100000, help='total images for which to generate visualizations')
parser.add_argument('--attn_thres', type=int, default=1, help='minimum # tokens of other modality required for global context')
parser.add_argument('--save_path', type=str, required=True, help='Path to save fused features')
parser.add_argument('--setting', type=str, default='viz', help='What training setting to use. Options: '
                                                                   'all: Train on all towns no validation data. '
                                                                   '02_05_withheld: Do not train on Town 02 and Town 05. Use the data as validation data.')
parser.add_argument('--backbone', type=str, default='transFuser',
                        help='Which Fusion backbone to use. Options: transFuser, late_fusion, latentTF, geometric_fusion')
parser.add_argument('--image_architecture', type=str, default='regnety_032',
                        help='Which architecture to use for the image branch. efficientnet_b0, resnet34, regnety_032 etc.')
parser.add_argument('--lidar_architecture', type=str, default='regnety_032',
                        help='Which architecture to use for the lidar branch. Tested: efficientnet_b0, resnet34, regnety_032 etc.')
parser.add_argument('--use_velocity', type=int, default=0,
                        help='Whether to use the velocity input. Currently only works with the TransFuser backbone. Expected values are 0:False, 1:True')
parser.add_argument('--use_target_point_image', type=int, default=1,
                        help='Valid values are 0, 1. 1 = using target point in the LiDAR0; 0 = dont do it')
parser.add_argument('--use_point_pillars', type=int, default=0,
                        help='Whether to use the point_pillar lidar encoder instead of voxelization. 0:False, 1:True')
parser.add_argument('--parallel_training', type=int, default=1,
                        help='If this is true/1 you need to launch the train.py script with CUDA_VISIBLE_DEVICES=0,1 torchrun --nnodes=1 --nproc_per_node=2 --max_restarts=0 --rdzv_id=123456780 --rdzv_backend=c10d train.py '
                             ' the code will be parallelized across GPUs. If set to false/0, you launch the script with python train.py and only 1 GPU will be used.')
parser.add_argument('--use_disk_cache', type=int, default=0, help='0: Do not cache the dataset 1: Cache the dataset on the disk pointed to by the SCRATCH enironment variable. Useful if the dataset is stored on slow HDDs and can be temporarily stored on faster SSD storage.')

args = parser.parse_args()

# Config
config = GlobalConfig(root_dir=args.root_dir, setting=args.setting)

# Ensure save_path exists
os.makedirs(args.save_path, exist_ok=True)

# Data
viz_data = CARLA_Data(root=config.viz_data, config=config)
dataloader_viz = DataLoader(viz_data, batch_size=args.batch_size, shuffle=False, num_workers=8, pin_memory=True)
'''
# Model
#model = TransFuser(config, args.device)
model = LidarCenterNet(config, args.device, args.backbone, args.image_architecture, args.lidar_architecture, bool(args.use_velocity))

model_parameters = filter(lambda p: p.requires_grad, model.parameters())
params = sum([np.prod(p.size()) for p in model_parameters])
print('Total parameters: ', params)
'''
parallel = bool(args.parallel_training)

if(bool(args.use_disk_cache) == True):
    if (parallel == True):
            # NOTE: This is specific to our cluster setup where the data is stored on slow storage.
            # During training we cache the dataset on the fast storage of the local compute nodes.
            # Adapt to your cluster setup as needed.
            # Important initialize the parallel threads from torch run to the same folder (so they can share the cache).
        tmp_folder = str(os.environ.get('SCRATCH'))
        print("Tmp folder for dataset cache: ", tmp_folder)
        tmp_folder = tmp_folder + "/dataset_cache"
            # We use a local diskcache to cache the dataset on the faster SSD drives on our cluster.
        shared_dict = Cache(directory=tmp_folder ,size_limit=int(768 * 1024 ** 3))
    else:
        shared_dict = Cache(size_limit=int(768 * 1024 ** 3))
else:
    shared_dict = None
'''
    # Use torchrun for starting because it has proper error handling. Local rank will be set automatically
if(parallel == True): #Non distributed works better with my local debugger
    rank       = int(os.environ["RANK"]) #Rank accross all processes
    local_rank = int(os.environ["LOCAL_RANK"]) # Rank on Node
    world_size = int(os.environ['WORLD_SIZE']) # Number of processes
    print(f"RANK, LOCAL_RANK and WORLD_SIZE in environ: {rank}/{local_rank}/{world_size}")

    device = torch.device('cuda:{}'.format(local_rank))
    os.environ["CUDA_VISIBLE_DEVICES"] = str(local_rank) # Hide devices that are not used by this process

    torch.distributed.init_process_group(backend='nccl', init_method='env://', world_size=world_size, rank=rank,
                                             timeout=datetime.timedelta(minutes=15))

    torch.distributed.barrier(device_ids=[local_rank])
else:
    rank       = 0
    local_rank = 0
    world_size = 1
    device = torch.device('cuda:{}'.format(local_rank))

torch.cuda.set_device(device)
'''
torch.backends.cudnn.benchmark = True # Wen want the highest performance

# Configure config
config = GlobalConfig(root_dir=args.root_dir, setting=args.setting)
config.use_target_point_image = bool(args.use_target_point_image)
#config.n_layer = args.n_layer
#config.use_point_pillars = bool(args.use_point_pillars)
config.backbone = args.backbone
'''
if(bool(args.no_bev_loss)):
    index_bev = config.detailed_losses.index("loss_bev")
    config.detailed_losses_weights[index_bev] = 0.0
'''
# Create model and optimizers
model = LidarCenterNet(config, args.device, args.backbone, args.image_architecture, args.lidar_architecture, bool(args.use_velocity))
'''
if (parallel == True):
    # Synchronizing the Batch Norms increases the Batch size with which they are compute by *num_gpus
    if(bool(args.sync_batch_norm) == True):
        model = torch.nn.SyncBatchNorm.convert_sync_batchnorm(model)
    model = torch.nn.parallel.DistributedDataParallel(model, device_ids=[local_rank], output_device=local_rank, broadcast_buffers=False, find_unused_parameters=False)
'''
model.cuda(device=args.device)
'''
if ((bool(args.zero_redundancy_optimizer) == True) and (parallel == True)):

    optimizer = ZeroRedundancyOptimizer(model.parameters(), optimizer_class=optim.AdamW, lr=args.lr) # Saves GPU memory during DDP training
else:
    optimizer = optim.AdamW(model.parameters(), lr=args.lr) # For single GPU training

'''
model_parameters = filter(lambda p: p.requires_grad, model.parameters())
params = sum([np.prod(p.size()) for p in model_parameters])
print ('Total trainable parameters: ', params)

model.load_state_dict(torch.load(os.path.join(args.model_path, 'model_seed3_37.pth')))
model.eval()

cnt = 0

# central tokens in both modalities, adjusted for alignment mismatch
central_image_tokens = list(range(16, 40))
central_lidar_tokens = list(range(4, 64, 8)) + list(range(6, 64, 8)) + list(range(5, 64, 8))
global_context = [[], [], [], []]

total_images_processed = 0
total_fronts_count = 0

with torch.no_grad():
    for enum, data in enumerate(tqdm(dataloader_viz)):
        
        if total_images_processed >= args.total_size:  # total images for which to generate visualizations
            break
        
        # create batch and move to GPU
        fronts_in = data['rgb']
        lidars_in = data['lidar']
        fronts = []
        lidars = []
        for i in range(config.seq_len):
            fronts.append(fronts_in[i].to(args.device, dtype=torch.float32))
            lidars.append(lidars_in[i].to(args.device, dtype=torch.float32))

        # driving labels
        command = data['command'].to(args.device)
        gt_velocity = data['speed'].to(args.device, dtype=torch.float32)

        # target point
        target_point = torch.stack(data['target_point'], dim=1).to(args.device, dtype=torch.float32)
        
        pred_wp, fused_features = model(fronts, lidars, target_point, gt_velocity)
        
        # Printing the total data[fronts]
        for seq in range(config.seq_len):
            print(f"Batch {enum}, Sequence {seq}, data['fronts']: {data['fronts'][seq].size()}")
            total_fronts_count += data['fronts'][seq].size(0)
        '''
        # Saving fused_features for the complete dataset
        for idx in range(fused_features.size(0)):
            front_filename = os.path.basename(data['fronts'][0][idx].path)
            lidar_filename = os.path.basename(data['lidars'][0][idx].path)
            feature_filename = f'fused_{front_filename}_{lidar_filename}.pt'
            feature_path = os.path.join(args.save_path, feature_filename)
            torch.save(fused_features[idx].cpu(), feature_path)

        total_images_processed += fused_features.size(0)
        '''
        for idx in range(fused_features.size(0)):
            feature_path = os.path.join(args.save_path, f'batch_{enum}_sample_{idx}.pt')
            torch.save(fused_features[idx].cpu(), feature_path)

        total_images_processed += fused_features.size(0)

print(f'Total images processed: {total_images_processed}')
print(f'Total fronts used: {total_fronts_count}')
