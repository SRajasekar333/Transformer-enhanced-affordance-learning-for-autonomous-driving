import argparse
import os
import datetime
import csv

from tqdm import tqdm
import numpy as np
import json
from PIL import Image, ImageDraw
import torch
from torch.utils.data import DataLoader

from config1 import GlobalConfig
from model import LidarCenterNet
from data import CARLA_Data

parser = argparse.ArgumentParser()
parser.add_argument('--root_dir', type=str, default=r'/data/horse/ws/rasa397c-Sankar/transfuser/data_mini', help='Root directory of your training data')
parser.add_argument('--model_path', type=str, required=True, help='path to model ckpt')
parser.add_argument('--args_path', type=str, required=True, help='path to training arguments')
parser.add_argument('--device', type=str, default='cuda', help='Device to use')
parser.add_argument('--batch_size', type=int, default=56, help='Batch size')
parser.add_argument('--save_path', type=str, default=None, help='path to save visualizations')
parser.add_argument('--total_size', type=int, default=100000, help='total images for which to generate visualizations')
parser.add_argument('--attn_thres', type=int, default=1, help='minimum # tokens of other modality required for global context')
# parser.add_argument('--backbone', type=str, default='transFuser', help='Which vision backbone to use. Options: geometric_fusion, transFuser, late_fusion, aim')
parser.add_argument('--setting', type=str, default='viz', help='What training setting to use. Options: '
                                                                   'all: Train on all towns no validation data. '
                                                                   '02_05_withheld: Do not train on Town 02 and Town 05. Use the data as validation data.')

args = parser.parse_args()

with open(args.args_path, 'r') as f:
	training_args = json.load(f)

# Config
#config = GlobalConfig()
config = GlobalConfig(root_dir=args.root_dir, setting=args.setting)
config.use_target_point_image = bool(training_args['use_target_point_image'])
config.n_layer = training_args['n_layer']

if args.save_path is not None and not os.path.isdir(args.save_path):
	os.makedirs(args.save_path, exist_ok=True)

# Data
viz_data = CARLA_Data(root=config.viz_data, config=config)
#dataloader_viz = DataLoader(viz_data, batch_size=args.batch_size, shuffle=False, num_workers=2, pin_memory=False)

##############   fullloader check   ###############
from torch.utils.data.dataloader import default_collate

def custom_collate_fn(batch):
    # Filter out NoneType items from the batch
    batch = [item for item in batch if item is not None]

    if len(batch) == 0:
        return None

    return default_collate(batch)

from torch.utils.data import DataLoader

# Use the custom collate function in your DataLoader
dataloader_viz = DataLoader(viz_data, batch_size=args.batch_size, shuffle=False, num_workers=1, collate_fn=custom_collate_fn)
##############   fullloader check   ###############

total_junction_count = 0

# Open CSV file to write
csv_file_path = os.path.join(args.save_path, 'annotations3333.csv')
with open(csv_file_path, mode='w', newline='') as csv_file:
    csv_writer = csv.writer(csv_file)
    # Write CSV header
    csv_writer.writerow(['batch', 'idx', 'target_speed', 'brake', 'junction', 'vehicle_hazard', 'light_hazard', 'walker_hazard', 'stop_sign_hazard', 'rel_angle', 'lateral_distance', 'distance'])

    for enum, data in enumerate(tqdm(dataloader_viz)):
        if data is None:  
            print(f"Batch {enum} is empty.")
            continue
        target_speed = data['target_speed'].to(args.device, dtype=torch.float32)
        brake = data['brake'].to(args.device, dtype=torch.float32)
        junction = data['junction'].to(args.device, dtype=torch.float32)
        vehicle_hazard = data['vehicle_hazard']
        light = data['light'].to(args.device, dtype=torch.float32)     
        walker_hazard = data['walker_hazard']  # This is a list of lists
        stop_sign_hazard = data['stop_sign_hazard'].to(args.device, dtype=torch.float32)
        rel_angle = data['angle'].to(args.device, dtype=torch.float32)
        lateral_distance = data['mean_lateral_distance'].to(args.device, dtype=torch.float32)
        distance = data['distance'].to(args.device, dtype=torch.float32)
        

        for idx in range(light.size(0)):
            brake_str = "true" if bool(brake[idx].item()) else "false"
            junction_str = "true" if bool(junction[idx].item()) else "false"
            light_str = "true" if bool(light[idx].item()) else "false"
            stop_sign_hazard_str = "true" if bool(stop_sign_hazard[idx].item()) else "false"

            # Check if all values in vehicle_hazard are the same and get the single boolean value
            vehicle_hazard_list = vehicle_hazard[idx].tolist()
            vehicle_hazard_str = "true" if all(vehicle_hazard_list) else "false"

            # Check if all values in walker_hazard are the same and get the single boolean value
            walker_hazard_list = walker_hazard[idx].tolist()
            walker_hazard_str = "true" if all(walker_hazard_list) else "false"

            target_distance = distance[idx].item()
            #rel_angle = rel_angle[idx].item()
            #lateral_distance = lateral_distance[idx].item()
            
            csv_writer.writerow([enum, idx, target_speed[idx].item(), brake_str, junction_str, vehicle_hazard_str, light_str, walker_hazard_str, stop_sign_hazard_str, rel_angle[idx].item(), lateral_distance[idx].item(), target_distance])
        
        total_junction_count += junction.size(0)

print(f'Total count of junction data: {total_junction_count}')
print(f'Data saved to CSV file: {csv_file_path}')