import argparse
import os
import datetime

from tqdm import tqdm
import numpy as np
import json
from PIL import Image, ImageDraw
import torch
from torch.utils.data import DataLoader

from config1 import GlobalConfig
from model import LidarCenterNet
from data import CARLA_Data

parser = argparse.ArgumentParser()
parser.add_argument('--root_dir', type=str, default=r'/data/horse/ws/rasa397c-Sankar/transfuser/data_mini', help='Root directory of your training data')
parser.add_argument('--model_path', type=str, required=True, help='path to model ckpt')
parser.add_argument('--args_path', type=str, required=True, help='path to training arguments')
parser.add_argument('--device', type=str, default='cuda', help='Device to use')
parser.add_argument('--batch_size', type=int, default=56, help='Batch size')
parser.add_argument('--save_path', type=str, default=None, help='path to save visualizations')
parser.add_argument('--total_size', type=int, default=100000, help='total images for which to generate visualizations')
parser.add_argument('--attn_thres', type=int, default=1, help='minimum # tokens of other modality required for global context')
# parser.add_argument('--backbone', type=str, default='transFuser', help='Which vision backbone to use. Options: geometric_fusion, transFuser, late_fusion, aim')
parser.add_argument('--setting', type=str, default='viz', help='What training setting to use. Options: '
                                                                   'all: Train on all towns no validation data. '
                                                                   '02_05_withheld: Do not train on Town 02 and Town 05. Use the data as validation data.')

args = parser.parse_args()

with open(args.args_path, 'r') as f:
	training_args = json.load(f)

# Config
#config = GlobalConfig()
config = GlobalConfig(root_dir=args.root_dir, setting=args.setting)
config.use_target_point_image = bool(training_args['use_target_point_image'])
config.n_layer = training_args['n_layer']

if args.save_path is not None and not os.path.isdir(args.save_path):
	os.makedirs(args.save_path, exist_ok=True)

# Data
viz_data = CARLA_Data(root=config.viz_data, config=config)
dataloader_viz = DataLoader(viz_data, batch_size=args.batch_size, shuffle=True, num_workers=8, pin_memory=False)

total_junction_count = 0

for enum, data in enumerate(tqdm(dataloader_viz)):
    junction = data['junction'].to(args.device, dtype=torch.float32)
    junction = data['junction'].to(args.device).float()
    #print(junction.size)
    #print(junction)
    junction_str = ["True" if bool(val) else "False" for val in junction]
    print(f'Batch {enum} Junction Data: {junction_str}')
    total_junction_count += junction.size(0)
    #for idx in range(light.size(0)):
        #feature_path = os.path.join(args.save_path, f'batch_{enum}_sample_{idx}.pt')
        #torch.save(fused_features[idx].cpu(), feature_path)
    #total_light_count += light.size(0)

print(f'Total count of junction data: {total_junction_count}')