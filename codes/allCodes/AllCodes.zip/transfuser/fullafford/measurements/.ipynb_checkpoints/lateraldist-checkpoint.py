import numpy as np
import json
import matplotlib.pyplot as plt
import matplotlib

# Use the 'Agg' backend for headless environments
matplotlib.use('Agg')

# If the data is saved in a JSON file, load it like this:
with open('/data/horse/ws/rasa397c-Sankar/transfuser/data_mini1/rr_dataset_23_11/Routes_clipped_Town05_rr_Seed0/clipped_Town05_rr_route6_11_23_16_12_20/measurements/0054.json', 'r') as f:
    data = json.load(f)

def point_to_segment_distance(px, py, x1, y1, x2, y2):
    """Calculate the distance from a point to a line segment."""
    line_vec = np.array([x2 - x1, y2 - y1])
    point_vec = np.array([px - x1, py - y1])
    line_len = np.linalg.norm(line_vec)
    
    line_unit_vec = line_vec / line_len
    projection_length = np.dot(point_vec, line_unit_vec)
    projection = projection_length * line_unit_vec
    
    if projection_length < 0:
        closest_point = np.array([x1, y1])
    elif projection_length > line_len:
        closest_point = np.array([x2, y2])
    else:
        closest_point = np.array([x1, y1]) + projection
    
    distance_vec = np.array([px, py]) - closest_point
    distance = np.linalg.norm(distance_vec)
    return distance, closest_point

# Extract vehicle position
vehicle_position = (data['x'], data['y'])

# Extract waypoints
waypoints = data['waypoints']

# Initialize minimum distance to a large value
min_distance = float('inf')
closest_point_on_segment = None

# Iterate over waypoints to form segments and calculate distances
for i in range(len(waypoints) - 1):
    x1, y1 = waypoints[i][:2]
    x2, y2 = waypoints[i + 1][:2]
    
    distance, closest_point = point_to_segment_distance(vehicle_position[0], vehicle_position[1], x1, y1, x2, y2)
    if distance < min_distance:
        min_distance = distance
        closest_point_on_segment = closest_point

print("Lateral distance to the centerline:", min_distance)

# Plotting
waypoints = np.array(waypoints)
plt.plot(waypoints[:, 0], waypoints[:, 1], 'r--', label='Center Line')
plt.scatter(vehicle_position[0], vehicle_position[1], c='b', label='Vehicle Position')
plt.plot([vehicle_position[0], closest_point_on_segment[0]], [vehicle_position[1], closest_point_on_segment[1]], 'g-', label='Measured Distance')
plt.scatter(closest_point_on_segment[0], closest_point_on_segment[1], c='g', label='Closest Point')

plt.legend()
plt.xlabel('X')
plt.ylabel('Y')
plt.title('Vehicle Position and Center Line')
plt.savefig('vehicle_centerline_distance.png')
plt.show()
