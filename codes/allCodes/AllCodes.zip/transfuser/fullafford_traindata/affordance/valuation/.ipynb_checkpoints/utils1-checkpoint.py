import matplotlib
matplotlib.use('Agg')  # Use the Agg backend for rendering plots in a headless environment
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from sklearn.metrics import classification_report, confusion_matrix, mean_squared_error, r2_score

def plot_predictions(predictions_df, annotations_df, output_dir):
    # Add your plotting code here, for example:
    for col in predictions_df.columns:
        plt.figure(figsize=(10, 5))
        plt.plot(predictions_df[col], label='Predictions')
        plt.plot(annotations_df[col], label='Annotations')
        plt.title(f'Predictions vs Annotations for {col}')
        plt.xlabel('Sample Index')
        plt.ylabel(col)
        plt.legend()
        plt.grid(True)
        plt.savefig(f'{output_dir}/plot_{col}.png')
        plt.close()

def classification_metrics(predictions_df, annotations_df, output_dir):
    # Generate a classification report for classification columns
    classification_cols = ['brake', 'junction', 'vehicle_hazard', 'light_hazard', 'walker_hazard', 'stop_sign_hazard']
    report = classification_report(annotations_df[classification_cols], predictions_df[classification_cols], output_dict=True)
    report_df = pd.DataFrame(report).transpose()
    report_df.to_csv(f'{output_dir}/classification_report.csv')
    print(f"Classification metrics saved to {output_dir}/classification_report.csv")

def regression_metrics(predictions_df, annotations_df, output_dir):
    # Calculate and save MSE for regression columns
    regression_cols = ['target_speed', 'rel_angle', 'lateral_distance', 'distance']
    mse = mean_squared_error(annotations_df[regression_cols], predictions_df[regression_cols])
    with open(f'{output_dir}/regression_metrics.txt', 'w') as f:
        f.write(f'Mean Squared Error (MSE) for regression targets: {mse}\n')
    print(f"Regression metrics saved to {output_dir}/regression_metrics.txt")
