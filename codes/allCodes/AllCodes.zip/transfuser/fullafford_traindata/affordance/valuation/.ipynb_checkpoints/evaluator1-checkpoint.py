import os
import torch
import pandas as pd
from utils1 import plot_predictions, classification_metrics, regression_metrics
import numpy as np

class Evaluator:
    def __init__(self, model, device):
        self.model = model
        self.device = device

    def evaluate(self, dataloader):
        self.model.eval()
        predictions = []
        with torch.no_grad():
            for features, _ in dataloader:
                features = features.to(self.device)
                outputs = self.model(features).cpu().numpy()
                
                # Split the outputs into regression and classification parts
                outputs_regression = outputs[:, [0, 7, 8, 9]]
                outputs_classification = outputs[:, 1:7]
                
                # Apply sigmoid to classification outputs to get probabilities
                outputs_classification = torch.sigmoid(torch.tensor(outputs_classification)).numpy()

                # Convert classification probabilities to binary (True/False) values
                outputs_classification_binary = outputs_classification > 0.5
                outputs_classification_binary = outputs_classification_binary.astype(int)
                
                # Combine them back
                outputs_combined = np.concatenate((outputs_regression, outputs_classification_binary), axis=1)
                predictions.append(outputs_combined)
                
        predictions = np.concatenate(predictions, axis=0)
        return predictions

    def save_predictions(self, predictions, annotations, output_dir):
        # Ensure the output directory exists
        os.makedirs(output_dir, exist_ok=True)
        
        # Define the path to save the predictions CSV file
        save_path = os.path.join(output_dir, 'predictions.csv')
        
        predictions_df = pd.DataFrame(predictions, columns=[
            'target_speed', 'rel_angle', 'lateral_distance', 'distance', 
            'brake', 'junction', 'vehicle_hazard', 'light_hazard', 'walker_hazard', 'stop_sign_hazard'
        ])
        
        # Convert classification values to 'True'/'False'
        for col in ['brake', 'junction', 'vehicle_hazard', 'light_hazard', 'walker_hazard', 'stop_sign_hazard']:
            predictions_df[col] = predictions_df[col].apply(lambda x: 'True' if x == 1 else 'False')
        
        predictions_df.to_csv(save_path, index=False)
        print(f"Predictions saved to {save_path}")

    def plot_and_evaluate(self, predictions_df, annotations_df, output_dir):
        # Ensure the output directory exists
        os.makedirs(output_dir, exist_ok=True)
        
        plot_predictions(predictions_df, annotations_df, output_dir)
        classification_metrics(predictions_df, annotations_df, output_dir)
        regression_metrics(predictions_df, annotations_df, output_dir)
