import argparse
import os
import datetime
import csv

from tqdm import tqdm
import numpy as np
import json
from PIL import Image, ImageDraw
import torch
from torch.utils.data import DataLoader

from config1 import GlobalConfig
from model import LidarCenterNet
from data import CARLA_Data

parser = argparse.ArgumentParser()
parser.add_argument('--root_dir', type=str, default=r'/data/horse/ws/rasa397c-Sankar/transfuser/data_mini', help='Root directory of your training data')
parser.add_argument('--model_path', type=str, required=True, help='path to model ckpt')
parser.add_argument('--args_path', type=str, required=True, help='path to training arguments')
parser.add_argument('--device', type=str, default='cuda', help='Device to use')
parser.add_argument('--batch_size', type=int, default=100, help='Batch size')
parser.add_argument('--save_path', type=str, default=None, help='path to save visualizations')
parser.add_argument('--total_size', type=int, default=1000000, help='total images for which to generate visualizations')
parser.add_argument('--attn_thres', type=int, default=1, help='minimum # tokens of other modality required for global context')
# parser.add_argument('--backbone', type=str, default='transFuser', help='Which vision backbone to use. Options: geometric_fusion, transFuser, late_fusion, aim')
parser.add_argument('--setting', type=str, default='viz1', help='What training setting to use. Options: '
                                                                   'all: Train on all towns no validation data. '
                                                                   '02_05_withheld: Do not train on Town 02 and Town 05. Use the data as validation data.')

args = parser.parse_args()

if not os.path.exists(args.save_path):
    os.makedirs(args.save_path)

csv_file_path = os.path.join(args.save_path, 'annotations_traindata.csv')

# Function to process hazard lists and determine the majority value
def get_majority_hazard(hazard_list):
    true_count = sum(hazard_list)
    false_count = len(hazard_list) - true_count
    return "true" if true_count > false_count else "false"

# Config
config = GlobalConfig(root_dir=args.root_dir, setting=args.setting)

# Data
viz_data = CARLA_Data(root=config.train_data, config=config)
dataloader_viz = DataLoader(viz_data, batch_size=args.batch_size, shuffle=False, num_workers=3, pin_memory=False)

# Open CSV file to write
with open(csv_file_path, mode='w', newline='') as csv_file:
    csv_writer = csv.writer(csv_file)
    # Write CSV header
    csv_writer.writerow(['batch', 'idx', 'target_speed', 'brake', 'junction', 'vehicle_hazard', 'light_hazard', 'walker_hazard', 'stop_sign_hazard', 'rel_angle', 'lateral_distance', 'distance'])

    for enum, data in enumerate(tqdm(dataloader_viz)):
        target_speed = data['target_speed'].to('cpu', dtype=torch.float32)
        brake = data['brake'].to('cpu', dtype=torch.float32)
        junction = data['junction'].to('cpu', dtype=torch.float32)
        vehicle_hazard = data['vehicle_hazard']
        light = data['light'].to('cpu', dtype=torch.float32)
        walker_hazard = data['walker_hazard']
        stop_sign_hazard = data['stop_sign_hazard'].to('cpu', dtype=torch.float32)
        rel_angle = data['angle'].to('cpu', dtype=torch.float32)
        lateral_distance = data['mean_lateral_distance'].to('cpu', dtype=torch.float32)
        distance = data['distance'].to('cpu', dtype=torch.float32)

        for idx in range(light.size(0)):
            brake_str = "true" if bool(brake[idx].item()) else "false"
            junction_str = "true" if bool(junction[idx].item()) else "false"
            light_str = "true" if bool(light[idx].item()) else "false"
            stop_sign_hazard_str = "true" if bool(stop_sign_hazard[idx].item()) else "false"

            # Process vehicle_hazard and walker_hazard
            vehicle_hazard_str = "false"
            walker_hazard_str = "false"
            if len(vehicle_hazard) > idx:
                vehicle_hazard_true_count = sum(vehicle_hazard[idx])
                vehicle_hazard_false_count = len(vehicle_hazard[idx]) - vehicle_hazard_true_count
                vehicle_hazard_str = "true" if vehicle_hazard_true_count > vehicle_hazard_false_count else "false"

            if len(walker_hazard) > idx:
                walker_hazard_true_count = sum(walker_hazard[idx])
                walker_hazard_false_count = len(walker_hazard[idx]) - walker_hazard_true_count
                walker_hazard_str = "true" if walker_hazard_true_count > walker_hazard_false_count else "false"

            csv_writer.writerow([
                enum, 
                idx, 
                target_speed[idx].item(), 
                brake_str, 
                junction_str, 
                vehicle_hazard_str, 
                light_str, 
                walker_hazard_str, 
                stop_sign_hazard_str, 
                rel_angle[idx].item(), 
                lateral_distance[idx].item(), 
                distance[idx].item()
            ])

print(f'Data saved to CSV file: {csv_file_path}')
'''
args = parser.parse_args()

with open(args.args_path, 'r') as f:
	training_args = json.load(f)

# Config
#config = GlobalConfig()
config = GlobalConfig(root_dir=args.root_dir, setting=args.setting)
config.use_target_point_image = bool(training_args['use_target_point_image'])
config.n_layer = training_args['n_layer']

if args.save_path is not None and not os.path.isdir(args.save_path):
	os.makedirs(args.save_path, exist_ok=True)

# Data
#viz_data = CARLA_Data(root=config.viz_data, config=config)
viz_data = CARLA_Data(root=config.train_data, config=config)
#dataloader_viz = DataLoader(viz_data, batch_size=args.batch_size, shuffle=False, num_workers=3, pin_memory=False)

##############   fullloader check   ###############
from torch.utils.data.dataloader import default_collate

def custom_collate_fn(batch):
    # Filter out NoneType items from the batch
    batch = [item for item in batch if item is not None]

    if len(batch) == 0:
        return None

    return default_collate(batch)

from torch.utils.data import DataLoader

# Use the custom collate function in your DataLoader
dataloader_viz = DataLoader(viz_data, batch_size=args.batch_size, shuffle=False, num_workers=1, collate_fn=custom_collate_fn)
##############   fullloader check   ###############

total_junction_count = 0

# Open CSV file to write
csv_file_path = os.path.join(args.save_path, 'annotations_traindata.csv')
with open(csv_file_path, mode='w', newline='') as csv_file:
    csv_writer = csv.writer(csv_file)
    # Write CSV header
    csv_writer.writerow(['batch', 'idx', 'target_speed', 'brake', 'junction', 'vehicle_hazard', 'light_hazard', 'walker_hazard', 'stop_sign_hazard', 'rel_angle', 'lateral_distance', 'distance'])

    for enum, data in enumerate(tqdm(dataloader_viz)):
        if data is None:  
            print(f"Batch {enum} is empty.")
            continue
        target_speed = data['target_speed'].to(args.device, dtype=torch.float32)
        brake = data['brake'].to(args.device, dtype=torch.float32)
        junction = data['junction'].to(args.device, dtype=torch.float32)
        vehicle_hazard = data['vehicle_hazard']
        light = data['light'].to(args.device, dtype=torch.float32)     
        walker_hazard = data['walker_hazard']  # This is a list of lists
        stop_sign_hazard = data['stop_sign_hazard'].to(args.device, dtype=torch.float32)
        rel_angle = data['angle'].to(args.device, dtype=torch.float32)
        lateral_distance = data['mean_lateral_distance'].to(args.device, dtype=torch.float32)
        distance = data['distance'].to(args.device, dtype=torch.float32)
        
        	
        for idx in range(light.size(0)):
            brake_str = "true" if bool(brake[idx].item()) else "false"
            junction_str = "true" if bool(junction[idx].item()) else "false"
            light_str = "true" if bool(light[idx].item()) else "false"
            stop_sign_hazard_str = "true" if bool(stop_sign_hazard[idx].item()) else "false"
            
            '''
            # Check if all values in vehicle_hazard are the same and get the single boolean value
            #vehicle_hazard_list = vehicle_hazard[idx].tolist()
            #vehicle_hazard_str = "true" if all(vehicle_hazard_list) else "false"
            vehicle_hazard_true_count = sum(vehicle_hazard[idx])
            vehicle_hazard_false_count = len(vehicle_hazard[idx]) - vehicle_hazard_true_count
            vehicle_hazard_str = "true" if vehicle_hazard_true_count > vehicle_hazard_false_count else "false"

            # Check if all values in walker_hazard are the same and get the single boolean value
            #walker_hazard_list = walker_hazard[idx].tolist()
            #walker_hazard_str = "true" if all(walker_hazard_list) else "false"
            walker_hazard_true_count = sum(walker_hazard[idx])
            walker_hazard_false_count = len(walker_hazard[idx]) - walker_hazard_true_count
            walker_hazard_str = "true" if walker_hazard_true_count > walker_hazard_false_count else "false"
            '''


            if len(vehicle_hazard) > idx:
                vehicle_hazard_true_count = sum(vehicle_hazard[idx])
                vehicle_hazard_false_count = len(vehicle_hazard[idx]) - vehicle_hazard_true_count
                vehicle_hazard_str = "true" if vehicle_hazard_true_count > vehicle_hazard_false_count else "false"
            else:
                vehicle_hazard_str = "false"

            # Find the majority value for walker_hazard
            if len(walker_hazard) > idx:
                walker_hazard_true_count = sum(walker_hazard[idx])
                walker_hazard_false_count = len(walker_hazard[idx]) - walker_hazard_true_count
                walker_hazard_str = "true" if walker_hazard_true_count > walker_hazard_false_count else "false"
            else:
                walker_hazard_str = "false"


            target_distance = distance[idx].item()
            #rel_angle = rel_angle[idx].item()
            #lateral_distance = lateral_distance[idx].item()
            
            csv_writer.writerow([enum, idx, target_speed[idx].item(), brake_str, junction_str, vehicle_hazard_str, light_str, walker_hazard_str, stop_sign_hazard_str, rel_angle[idx].item(), lateral_distance[idx].item(), target_distance])
        
        total_junction_count += junction.size(0)
        
        '''
        print(light.size(0))
        for idx in range(light.size(0)):
            brake_str = "true" if bool(brake[idx].item()) else "false"
            junction_str = "true" if bool(junction[idx].item()) else "false"
            light_str = "true" if bool(light[idx].item()) else "false"
            stop_sign_hazard_str = "true" if bool(stop_sign_hazard[idx].item()) else "false"

            try:
                # Check if all values in vehicle_hazard are the same and get the single boolean value
                vehicle_hazard_list = vehicle_hazard[idx].tolist()
                print()
                vehicle_hazard_str = "true" if all(vehicle_hazard_list) else "false"

                # Check if all values in walker_hazard are the same and get the single boolean value
                walker_hazard_list = walker_hazard[idx].tolist()
                walker_hazard_str = "true" if all(walker_hazard_list) else "false"

                target_distance = distance[idx].item()

                csv_writer.writerow([enum, idx, target_speed[idx].item(), brake_str, junction_str, vehicle_hazard_str, light_str, walker_hazard_str, stop_sign_hazard_str, rel_angle[idx].item(), lateral_distance[idx].item(), target_distance])
            except IndexError:
                print(f"Index {idx} is out of range for one of the data lists.")
        
        total_junction_count += junction.size(0)
        '''
        '''
        for idx in range(light.size(0)):
            brake_str = "true" if bool(brake[idx].item()) else "false"
            junction_str = "true" if bool(junction[idx].item()) else "false"
            light_str = "true" if bool(light[idx].item()) else "false"
            stop_sign_hazard_str = "true" if bool(stop_sign_hazard[idx].item()) else "false"

            # Check if all values in vehicle_hazard are the same and get the single boolean value
            if all(vehicle_hazard[idx]):
                vehicle_hazard_str = "true"
            elif not any(vehicle_hazard[idx]):
                vehicle_hazard_str = "false"
            #else:
                #vehicle_hazard_str = "mixed"  # or handle as you see fit

            # Check if all values in walker_hazard are the same and get the single boolean value
            if all(walker_hazard[idx]):
                walker_hazard_str = "true"
            elif not any(walker_hazard[idx]):
                walker_hazard_str = "false"
            #else:
                #walker_hazard_str = "mixed"  # or handle as you see fit

            target_distance = distance[idx].item()

            csv_writer.writerow([enum, idx, target_speed[idx].item(), brake_str, junction_str, vehicle_hazard_str, light_str, walker_hazard_str, stop_sign_hazard_str, rel_angle[idx].item(), lateral_distance[idx].item(), target_distance])
        
        total_junction_count += junction.size(0)
        '''

print(f'Total count of junction data: {total_junction_count}')
print(f'Data saved to CSV file: {csv_file_path}')

import argparse
import os
import csv
import json
from tqdm import tqdm

parser = argparse.ArgumentParser()
parser.add_argument('--root_dir', type=str, required=True, help='Root directory of your training data')
parser.add_argument('--save_path', type=str, required=True, help='path to save the CSV file')
args = parser.parse_args()

if not os.path.exists(args.save_path):
    os.makedirs(args.save_path)

csv_file_path = os.path.join(args.save_path, 'annotations_traindata.csv')

# Function to process hazard lists and determine the majority value
def get_majority_hazard(hazard_list):
    true_count = sum(hazard_list)
    false_count = len(hazard_list) - true_count
    return "true" if true_count > false_count else "false"

# Open CSV file to write
with open(csv_file_path, mode='w', newline='') as csv_file:
    csv_writer = csv.writer(csv_file)
    # Write CSV header
    csv_writer.writerow(['file_name', 'target_speed', 'brake', 'junction', 'vehicle_hazard', 'light_hazard', 'walker_hazard', 'stop_sign_hazard', 'rel_angle', 'lateral_distance', 'distance'])
    for enum, data in enumerate(tqdm(dataloader_viz)):
        if data is None:  
            print(f"Batch {enum} is empty.")
            continue
        target_speed = data['target_speed'].to(args.device, dtype=torch.float32)
        brake = data['brake'].to(args.device, dtype=torch.float32)
        junction = data['junction'].to(args.device, dtype=torch.float32)
        vehicle_hazard = data['vehicle_hazard']
        light = data['light'].to(args.device, dtype=torch.float32)     
        walker_hazard = data['walker_hazard']  # This is a list of lists
        stop_sign_hazard = data['stop_sign_hazard'].to(args.device, dtype=torch.float32)
        rel_angle = data['angle'].to(args.device, dtype=torch.float32)
        lateral_distance = data['mean_lateral_distance'].to(args.device, dtype=torch.float32)
        distance = data['distance'].to(args.device, dtype=torch.float32)
    '''
    # Iterate over all JSON files in the root directory
    for subdir, _, files in os.walk(args.root_dir):
        for file in tqdm(files):
            if file.endswith('.json'):
                file_path = os.path.join(subdir, file)
                with open(file_path, 'r') as f:
                    data = json.load(f)

                target_speed = data.get('target_speed', 0)
                brake_str = "true" if data.get('brake', False) else "false"
                junction_str = "true" if data.get('junction', False) else "false"
                light_hazard_str = "true" if data.get('light_hazard', False) else "false"
                stop_sign_hazard_str = "true" if data.get('stop_sign_hazard', False) else "false"

                vehicle_hazard_str = get_majority_hazard(data.get('vehicle_hazard', []))
                walker_hazard_str = get_majority_hazard(data.get('walker_hazard', []))

                rel_angle = data.get('angle', 0)
                lateral_distance = data.get('lateral_distance', 0)
                distance = data.get('distance', 0)

                csv_writer.writerow([file, target_speed, brake_str, junction_str, vehicle_hazard_str, light_hazard_str, walker_hazard_str, stop_sign_hazard_str, rel_angle, lateral_distance, distance])
    '''

print(f'Data saved to CSV file: {csv_file_path}')
'''