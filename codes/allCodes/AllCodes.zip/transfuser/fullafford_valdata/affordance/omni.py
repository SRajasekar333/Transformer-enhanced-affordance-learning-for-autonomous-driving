import os
import torch
import pandas as pd
from model1 import AffordancePredictor
from data_loader1 import DataLoaderWrapper
from evaluator1 import Evaluator
from utils1 import classification_metrics, regression_metrics
import argparse

print("started")

def load_model(model_path, input_dim, hidden_dim, num_regression_outputs, num_classification_outputs, device='cuda'):
    model = AffordancePredictor(input_dim, hidden_dim, num_regression_outputs, num_classification_outputs)
    model.load_state_dict(torch.load(model_path, map_location=device))
    model.to(device)
    model.eval()  # Set the model to evaluation mode
    return model

#def save_model(model, output_path):
   # torch.save(model.state_dict(), output_path)

def train_and_evaluate(model, validation_loader, device, learning_rate, num_epochs=5):
    """Train the model and evaluate its performance on the validation set."""
    # Define loss function and optimizer
    criterion = torch.nn.MSELoss()  # Assuming regression loss for optimization
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)

    # Train model
    model.train()
    for epoch in range(num_epochs):  # Short training for validation
        print(epoch)
        running_loss = 0.0
        for features, annotations in validation_loader:
            features = features.to(device)
            annotations = annotations.to(device)

            optimizer.zero_grad()
            outputs_regression, outputs_classification = model(features)
            loss = criterion(outputs_regression, annotations[:, :4])  # Use regression part for validation
            loss.backward()
            optimizer.step()
            running_loss += loss.item()
    
    avg_loss = running_loss / len(validation_loader)
    print(f'Validation Loss: {avg_loss}')
    
    #print statement esp. for OmniOpt (single line!!)
    print(f"RESULT: {avg_loss:>8f} \n")

    return avg_loss

def main():
    # Argument parser for hyperparameters
    parser = argparse.ArgumentParser(description="Hyperparameter Optimization for Affordance Predictor")
    parser.add_argument('--hidden_dim', type=int, default=128, help="Hidden dimension for the model")
    parser.add_argument('--learning_rate', type=float, default=0.001, help="Learning rate for the optimizer")
    parser.add_argument('--num_epochs', type=int, default=5, help="Number of epochs for training")

    args = parser.parse_args()

    # Paths and settings
    base_dir = "/data/horse/ws/rasa397c-Sankar/Multimodal/transfuser/model_ckpt/"
    root_dir = f'{base_dir}/fullafford_valdata1_transfuser1'
    annotations_path = os.path.join(root_dir, 'annotations_valdata.csv')
    model_path = '/data/horse/ws/rasa397c-Sankar/Multimodal/transfuser/model_ckpt/valuation_tf_train_val/model_new_300.pth'
    output_dir = '/data/horse/ws/rasa397c-Sankar/Multimodal/transfuser/model_ckpt/valuation_tf_train_val/output_hyper/args'
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    input_dim = 512
    num_regression_outputs = 4
    num_classification_outputs = 6
    batch_size = 100  # Fixed batch size

    # Ensure the output directory exists
    os.makedirs(output_dir, exist_ok=True)

    # Load annotations and create data loader
    data_loader_wrapper = DataLoaderWrapper(root_dir=root_dir, batch_size=batch_size)
    annotations = data_loader_wrapper.load_annotations(annotations_path)
    features_paths = data_loader_wrapper.get_feature_paths(annotations)
    validation_loader = data_loader_wrapper.create_dataloader(features_paths, annotations)

    # Initialize and train model
    model = AffordancePredictor(input_dim, args.hidden_dim, num_regression_outputs, num_classification_outputs)
    model.to(device)

    avg_loss = train_and_evaluate(model, validation_loader, device, args.learning_rate, args.num_epochs)

    # Save the trained model
    

if __name__ == '__main__':
    main()


