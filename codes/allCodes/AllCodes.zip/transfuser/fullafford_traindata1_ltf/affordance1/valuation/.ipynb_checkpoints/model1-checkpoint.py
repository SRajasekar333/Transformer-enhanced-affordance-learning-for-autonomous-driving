'''
import torch
import torch.nn as nn

class AffordancePredictor(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim):
        super(AffordancePredictor, self).__init__()
        self.fc1 = nn.Linear(input_dim, hidden_dim)
        self.relu = nn.ReLU()
        self.fc2 = nn.Linear(hidden_dim, hidden_dim)
        self.fc3 = nn.Linear(hidden_dim, output_dim)
    
    def forward(self, x):
        x = self.fc1(x)
        x = self.relu(x)
        x = self.fc2(x)
        x = self.relu(x)
        x = self.fc3(x)
        return x

'''
import torch
import torch.nn as nn

class AffordancePredictor(nn.Module):
    def __init__(self, input_dim, hidden_dim, num_regression_outputs, num_classification_outputs):
        super(AffordancePredictor, self).__init__()
        self.fc1 = nn.Linear(input_dim, hidden_dim)
        self.relu = nn.ReLU()
        self.fc2 = nn.Linear(hidden_dim, hidden_dim)

        # Separate output layers for regression and classification
        self.regression_head = nn.Linear(hidden_dim, num_regression_outputs)
        self.classification_head = nn.Linear(hidden_dim, num_classification_outputs)

    def forward(self, x):
        x = self.fc1(x)
        x = self.relu(x)
        x = self.fc2(x)
        x = self.relu(x)

        # Compute separate outputs
        regression_outputs = self.regression_head(x)  # Linear output for regression
        classification_outputs = self.classification_head(x)  # Raw output for classification

        return regression_outputs, classification_outputs
