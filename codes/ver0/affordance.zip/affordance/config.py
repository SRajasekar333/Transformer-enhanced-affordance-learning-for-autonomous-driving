class GlobalConfig:
    def __init__(self, root_dir, setting):
        self.root_dir = root_dir
        self.setting = setting
        self.use_target_point_image = False
        self.n_layer = 3
