'''
import matplotlib
import matplotlib.pyplot as plt
matplotlib.use('Agg')  # Use the Agg backend for rendering plots in a headless environment
from sklearn.metrics import classification_report, confusion_matrix
import os
import pandas as pd
'''
'''
def plot_predictions(predictions, annotations, save_path):
    for col in annotations.columns:
        if col in ['batch', 'idx']:
            continue
        plt.figure(figsize=(10, 6))
        plt.plot(predictions[col], label='Predicted')
        plt.plot(annotations[col], label='Actual')
        plt.title(f'Predictions vs Actuals for {col}')
        plt.xlabel('Sample')
        plt.ylabel(col)
        plt.legend()
        plt.savefig(os.path.join(save_path, f'{col}_pred_vs_actual.png'))
        plt.close()
'''
'''
def plot_predictions(predictions, annotations, save_path):
    metrics = ['target_speed', 'brake', 'junction', 'vehicle_hazard', 'light_hazard', 'walker_hazard', 'stop_sign_hazard']
    
    for metric in metrics:
        plt.figure(figsize=(10, 6))
        plt.plot(predictions[metric], label='Predicted')
        plt.plot(annotations[metric], label='Actual')
        plt.xlabel('Sample Index')
        plt.ylabel(metric)
        plt.title(f'Predicted vs Actual {metric}')
        plt.legend()
        plt.savefig(f'{save_path}/{metric}_comparison.png')
        plt.close()
        
def plot_confusion_matrix(y_true, y_pred, title, save_path):
    cm = confusion_matrix(y_true, y_pred)
    plt.figure(figsize=(10, 7))
    plt.imshow(cm, interpolation='nearest', cmap=plt.get_cmap('Blues'))
    plt.title(title)
    plt.colorbar()
    tick_marks = range(len(set(y_true)))
    plt.xticks(tick_marks, tick_marks)
    plt.yticks(tick_marks, tick_marks)
    plt.ylabel('True label')
    plt.xlabel('Predicted label')
    plt.savefig(save_path)
    plt.close()

def classification_metrics(predictions, annotations, save_path):
    report = classification_report(annotations, predictions, output_dict=True)
    df_report = pd.DataFrame(report).transpose()
    df_report.to_csv(os.path.join(save_path, 'classification_report.csv'))
    
    for col in annotations.columns:
        if col in ['batch', 'idx']:
            continue
        plot_confusion_matrix(annotations[col], predictions[col], f'Confusion Matrix for {col}', os.path.join(save_path, f'{col}_confusion_matrix.png'))
'''
import matplotlib
matplotlib.use('Agg')  # Use the Agg backend for rendering plots in a headless environment
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from sklearn.metrics import classification_report, confusion_matrix, mean_squared_error, r2_score

def plot_predictions(predictions, annotations, save_path):
    metrics = ['target_speed', 'brake', 'junction', 'vehicle_hazard', 'light_hazard', 'walker_hazard', 'stop_sign_hazard', 'rel_angle', 'lateral_distance', 'distance']
    
    for metric in metrics:
        plt.figure(figsize=(10, 6))
        plt.plot(predictions[metric], label='Predicted')
        plt.plot(annotations[metric], label='Actual')
        plt.xlabel('Sample Index')
        plt.ylabel(metric)
        plt.title(f'Predicted vs Actual {metric}')
        plt.legend()
        plt.savefig(f'{save_path}/{metric}_comparison.png')
        plt.close()
'''
def classification_metrics(predictions, annotations, save_path):
    metrics = ['brake', 'junction', 'vehicle_hazard', 'light_hazard', 'walker_hazard', 'stop_sign_hazard']
    for metric in metrics:
        report = classification_report(annotations[metric], predictions[metric], output_dict=True)
        print(f'Classification Report for {metric}:\n', report)
        
        cm = confusion_matrix(annotations[metric], predictions[metric])
        plt.figure(figsize=(10, 6))
        plt.imshow(cm, interpolation='nearest', cmap=plt.cm.Blues)
        plt.title(f'Confusion Matrix for {metric}')
        plt.colorbar()
        plt.ylabel('True label')
        plt.xlabel('Predicted label')
        plt.savefig(f'{save_path}/{metric}_confusion_matrix.png')
        plt.close()
'''
def classification_metrics(predictions, annotations, save_path):
    metrics = ['brake', 'junction', 'vehicle_hazard', 'light_hazard', 'walker_hazard', 'stop_sign_hazard']
    for metric in metrics:
        if annotations[metric].nunique() <= 2:  # Ensure the target is binary
            report = classification_report(annotations[metric], predictions[metric].round(), output_dict=True)
            print(f'Classification Report for {metric}:\n', report)
            
            cm = confusion_matrix(annotations[metric], predictions[metric].round())
            plt.figure(figsize=(10, 6))
            plt.imshow(cm, interpolation='nearest', cmap=plt.cm.Blues)
            plt.title(f'Confusion Matrix for {metric}')
            plt.colorbar()
            plt.ylabel('True label')
            plt.xlabel('Predicted label')
            plt.savefig(f'{save_path}/{metric}_confusion_matrix.png')
            plt.close()
            
def regression_metrics(predictions, annotations, save_path):
    metrics = ['target_speed', 'rel_angle', 'lateral_distance', 'distance']
    for metric in metrics:
        mse = mean_squared_error(annotations[metric], predictions[metric])
        r2 = r2_score(annotations[metric], predictions[metric])
        print(f'{metric} - Mean Squared Error: {mse}, R^2 Score: {r2}')
        
        plt.figure(figsize=(10, 6))
        plt.scatter(annotations[metric], predictions[metric], alpha=0.5)
        plt.xlabel('Actual')
        plt.ylabel('Predicted')
        plt.title(f'Predicted vs Actual {metric}')
        plt.savefig(f'{save_path}/{metric}_scatter.png')
        plt.close()
