import argparse
import os
import torch
from config1 import GlobalConfig
from model import AffordancePredictor
from data_loader import DataLoader
from evaluator import Evaluator

def main(args):
    # Load training arguments
    with open(args.args_path, 'r') as f:
        training_args = json.load(f)

    # Config
    config = GlobalConfig(root_dir=args.root_dir, setting=args.setting)
    config.use_target_point_image = bool(training_args['use_target_point_image'])
    config.n_layer = training_args['n_layer']

    if args.save_path is not None and not os.path.isdir(args.save_path):
        os.makedirs(args.save_path, exist_ok=True)

    # Data
    data_loader = DataLoader(root_dir=config.viz_data, batch_size=args.batch_size)
    annotations = data_loader.load_annotations(os.path.join(args.root_dir, 'annotations2.csv'))
    features_paths = data_loader.get_feature_paths(annotations)
    features_list = data_loader.load_data(features_paths)

    # Model
    input_dim = 512  # This should match the dimensionality of your fused features
    hidden_dim = 256
    output_dim = 7  # Number of affordances to predict
    model = AffordancePredictor(input_dim, hidden_dim, output_dim)

    # Load the model checkpoint
    model.load_state_dict(torch.load(args.model_path))

    # Evaluator
    evaluator = Evaluator(model)
    predictions = evaluator.evaluate(features_list, annotations)

    print(f'Evaluation complete. Total samples evaluated: {len(predictions)}')

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--root_dir', type=str, required=True, help='Root directory of your training data')
    parser.add_argument('--model_path', type=str, required=True, help='Path to model checkpoint')
    parser.add_argument('--args_path', type=str, required=True, help='Path to training arguments')
    parser.add_argument('--device', type=str, default='cuda', help='Device to use')
    parser.add_argument('--batch_size', type=int, default=56, help='Batch size')
    parser.add_argument('--save_path', type=str, default=None, help='Path to save visualizations')
    parser.add_argument('--total_size', type=int, default=100000, help='Total images for which to generate visualizations')
    parser.add_argument('--attn_thres', type=int, default=1, help='Minimum # tokens of other modality required for global context')
    parser.add_argument('--setting', type=str, default='viz', help='What training setting to use. Options: '
                                                                       'all: Train on all towns no validation data. '
                                                                       '02_05_withheld: Do not train on Town 02 and Town 05. Use the data as validation data.')
    args = parser.parse_args()
    main(args)
