'''
import argparse
import os
import json
import torch
import pandas as pd
from config import GlobalConfig
from data_loader import DataLoaderWrapper
from model import AffordancePredictor
from trainer import Trainer
from evaluator import Evaluator

def main(args):
    # Load training arguments
    with open(args.args_path, 'r') as f:
        training_args = json.load(f)

    # Config
    config = GlobalConfig(root_dir=args.root_dir, setting=args.setting)
    config.use_target_point_image = bool(training_args['use_target_point_image'])
    config.n_layer = training_args['n_layer']

    if args.save_path is not None and not os.path.isdir(args.save_path):
        os.makedirs(args.save_path, exist_ok=True)

    # Data
    data_loader_wrapper = DataLoaderWrapper(root_dir=config.root_dir, batch_size=args.batch_size)
    annotations = data_loader_wrapper.load_annotations(os.path.join(args.root_dir, 'annotations_traindata_noNan.csv'))
    features_paths = data_loader_wrapper.get_feature_paths(annotations)
    dataloader = data_loader_wrapper.create_dataloader(features_paths, annotations)
    #train_loader, val_loader = data_loader_wrapper.create_train_val_dataloaders(features_paths, annotations)

    # Model
    input_dim = 512  # This should match the dimensionality of your fused features
    hidden_dim = 256
    
    output_dim = 10  # Number of affordances to predict, adjust accordingly
    model = AffordancePredictor(input_dim, hidden_dim, output_dim)
    model.to(args.device)

    
    #model = YourModelClass()
    #device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    #train_dataloader = DataLoader(YourDatasetClass(), batch_size=64, shuffle=True)
    #val_dataloader = DataLoader(YourDatasetClass(), batch_size=64, shuffle=False)
    

    # Trainer
    trainer = Trainer(model, args.device, dataloader, lr=1e-4, epochs=100)
    #trainer = Trainer(model, args.device, train_loader, val_loader, lr=1e-3, epochs=10)
    trainer.train()
    model_save_path = os.path.join(args.save_path, 'model.pth')
    trainer.save_model(model_save_path)

    # Load trained model
    model.load_state_dict(torch.load(model_save_path))
    model.to(args.device)

    # Evaluator
    evaluator = Evaluator(model, args.device)
    predictions = evaluator.evaluate(dataloader)
    #predictions = evaluator.evaluate(val_loader)

    # Save predictions
    predictions_save_path = os.path.join(args.save_path, 'predictions_traindata_new_withwt.csv')
    evaluator.save_predictions(predictions, annotations, predictions_save_path)

    # Load predictions and annotations as DataFrames
    predictions_df = pd.DataFrame(predictions, columns=annotations.columns[2:])
    annotations_df = annotations.drop(columns=['batch', 'idx'])

    # Plot and evaluate
    evaluator.plot_and_evaluate(predictions_df, annotations_df, args.save_path)

    print(f'Total count of samples: {len(predictions)}')
    print(f'Data saved to CSV file: {predictions_save_path}')

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--root_dir', type=str, required=True, help='Root directory of your training data')
    parser.add_argument('--args_path', type=str, required=True, help='Path to training arguments')
    parser.add_argument('--device', type=str, default='cuda', help='Device to use')
    parser.add_argument('--batch_size', type=int, default=56, help='Batch size')
    parser.add_argument('--save_path', type=str, default=None, help='Path to save visualizations and model')
    parser.add_argument('--total_size', type=int, default=100000, help='Total images for which to generate visualizations')
    parser.add_argument('--attn_thres', type=int, default=1, help='Minimum # tokens of other modality required for global context')
    parser.add_argument('--setting', type=str, default='viz', help='What training setting to use. Options: '
                                                                       'all: Train on all towns no validation data. '
                                                                       '02_05_withheld: Do not train on Town 02 and Town 05. Use the data as validation data.')
    args = parser.parse_args()
    main(args)
'''
######new method

import argparse
import os
import json
import torch
import pandas as pd
from config import GlobalConfig
from data_loader import DataLoaderWrapper
from model import AffordancePredictor
from trainer import Trainer
from evaluator import Evaluator
import numpy as np

def main(args):
    # Load training arguments
    with open(args.args_path, 'r') as f:
        training_args = json.load(f)

    # Config
    config = GlobalConfig(root_dir=args.root_dir, setting=args.setting)
    config.use_target_point_image = bool(training_args['use_target_point_image'])
    config.n_layer = training_args['n_layer']

    if args.save_path is not None and not os.path.isdir(args.save_path):
        os.makedirs(args.save_path, exist_ok=True)

    # Data
    data_loader_wrapper = DataLoaderWrapper(root_dir=config.root_dir, batch_size=args.batch_size)
    annotations = data_loader_wrapper.load_annotations(os.path.join(args.root_dir, 'annotations_trans_preddata.csv'))
    
    #if annotations.isnull().values.any() or np.isinf(annotations.values).any():
        #print("Data contains NaN or infinite values. Please clean your data.")
    #else:
        #print("Data is clean.")
        
        
    features_paths = data_loader_wrapper.get_feature_paths(annotations)
    dataloader = data_loader_wrapper.create_dataloader(features_paths, annotations)

    # Model
    input_dim = 512  # This should match the dimensionality of your fused features
    hidden_dim = 256
    num_regression_outputs = 4  # Number of regression outputs
    num_classification_outputs = 6  # Number of classification outputs
    model = AffordancePredictor(input_dim, hidden_dim, num_regression_outputs, num_classification_outputs)
    model.to(args.device)

    # Trainer
    trainer = Trainer(model, args.device, dataloader, lr=1e-4, epochs=200)
    trainer.train()
    model_save_path = os.path.join(args.save_path, 'model.pth')
    trainer.save_model(model_save_path)

    # Load trained model
    model.load_state_dict(torch.load(model_save_path))
    model.to(args.device)

    # Evaluator
    evaluator = Evaluator(model, args.device)
    predictions = evaluator.evaluate(dataloader)

    # Save predictions
    predictions_save_path = os.path.join(args.save_path, 'predictions_trans_preddata.csv')
    evaluator.save_predictions(predictions, annotations, predictions_save_path)

    # Load predictions and annotations as DataFrames
    predictions_df = pd.DataFrame(predictions, columns=[
        'target_speed', 'rel_angle', 'lateral_distance', 'distance', 
        'brake', 'junction', 'vehicle_hazard', 'light_hazard', 'walker_hazard', 'stop_sign_hazard'
    ])
    annotations_df = annotations.drop(columns=['batch', 'idx'])

    # Plot and evaluate
    evaluator.plot_and_evaluate(predictions_df, annotations_df, args.save_path)

    print(f'Total count of samples: {len(predictions_df)}')
    print(f'Data saved to CSV file: {predictions_save_path}')

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--root_dir', type=str, required=True, help='Root directory of your training data')
    parser.add_argument('--args_path', type=str, required=True, help='Path to training arguments')
    parser.add_argument('--device', type=str, default='cuda', help='Device to use')
    parser.add_argument('--batch_size', type=int, default=56, help='Batch size')
    parser.add_argument('--save_path', type=str, default=None, help='Path to save visualizations and model')
    parser.add_argument('--total_size', type=int, default=100000, help='Total images for which to generate visualizations')
    parser.add_argument('--attn_thres', type=int, default=1, help='Minimum # tokens of other modality required for global context')
    parser.add_argument('--setting', type=str, default='viz', help='What training setting to use. Options: '
                                                                       'all: Train on all towns no validation data. '
                                                                       '02_05_withheld: Do not train on Town 02 and Town 05. Use the data as validation data.')
    args = parser.parse_args()
    main(args)
