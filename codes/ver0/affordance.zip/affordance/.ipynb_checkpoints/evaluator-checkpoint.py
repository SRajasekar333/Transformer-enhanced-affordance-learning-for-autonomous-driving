#import torch
'''
class Evaluator:
    def __init__(self, model):
        self.model = model

    def task_block(self, features):
        self.model.eval()
        with torch.no_grad():
            features = torch.tensor(features)
            predictions = self.model(features)
        return predictions

    def parse_predictions(self, predictions):
        return {
            'target_speed': predictions[0].item(),
            'brake': "true" if predictions[1].item() > 0.5 else "false",
            'junction': "true" if predictions[2].item() > 0.5 else "false",
            'vehicle_hazard': "true" if predictions[3].item() > 0.5 else "false",
            'light_hazard': "true" if predictions[4].item() > 0.5 else "false",
            'walker_hazard': "true" if predictions[5].item() > 0.5 else "false",
            'stop_sign_hazard': "true" if predictions[6].item() > 0.5 else "false",
        }

    def evaluate(self, features_list, annotations):
        predictions_list = []
        for i, features in enumerate(features_list):
            predictions = self.task_block(features)
            parsed_predictions = self.parse_predictions(predictions)
            predictions_list.append(parsed_predictions)
            print(f"Sample {i}:")
            print(f"Predictions: {parsed_predictions}")
            print(f"Annotations: {annotations[i]}")
        return predictions_list
'''
'''
import torch
import pandas as pd
from utils import plot_predictions, classification_metrics

class Evaluator:
    def __init__(self, model, device):
        self.model = model
        self.device = device

    def evaluate(self, dataloader):
        self.model.eval()
        predictions = []

        with torch.no_grad():
            for features, annotations in dataloader:
                features = features.to(self.device)
                output = self.model(features)
                predictions.extend(output.cpu().numpy())

        return predictions

    def save_predictions(self, predictions, annotations, save_path):
        results = annotations.copy()
        results['predictions'] = predictions
        results.to_csv(save_path, index=False)

    def plot_and_evaluate(self, predictions, annotations, save_path):
        plot_predictions(predictions, annotations, save_path)
        classification_metrics(predictions, annotations, save_path)
'''
'''
################################# old version ########################################
import os
import torch
import pandas as pd
from utils import plot_predictions, classification_metrics, regression_metrics
import numpy as np

class Evaluator:
    def __init__(self, model, device):
        self.model = model
        self.device = device

    def evaluate(self, dataloader):
        self.model.eval()
        predictions = []
        with torch.no_grad():
            for features, _ in dataloader:
                features = features.to(self.device)
                outputs = self.model(features)
                #predictions.append(outputs.cpu().numpy())
                
                outputs = outputs.cpu().numpy()
                
                # Split the outputs into regression and classification parts
                outputs_regression = outputs[:, [0, 7, 8, 9]]
                outputs_classification = outputs[:, 1:7]
                
                # Apply sigmoid to classification outputs to get probabilities
                outputs_classification = torch.sigmoid(torch.tensor(outputs_classification)).numpy()

                # Convert classification probabilities to binary (True/False) values
                outputs_classification_binary = outputs_classification > 0.5
                outputs_classification_binary = outputs_classification_binary.astype(int)
                
                # Combine them back
                outputs_combined = np.concatenate((outputs_regression, outputs_classification_binary), axis=1)
                predictions.append(outputs_combined)
                
        predictions = np.concatenate(predictions, axis=0)
        return predictions
    
    #def save_predictions(self, predictions, annotations, save_path):
        #predictions_df = pd.DataFrame(predictions, columns=annotations.columns[2:])
        #predictions_df.to_csv(save_path, index=False)
    
    def save_predictions(self, predictions, annotations, save_path):
        predictions_df = pd.DataFrame(predictions, columns=[
            'target_speed', 'rel_angle', 'lateral_distance', 'distance', 
            'brake', 'junction', 'vehicle_hazard', 'light_hazard', 'walker_hazard', 'stop_sign_hazard'
        ])
        
        # Convert classification values to 'True'/'False'
        for col in ['brake', 'junction', 'vehicle_hazard', 'light_hazard', 'walker_hazard', 'stop_sign_hazard']:
            predictions_df[col] = predictions_df[col].apply(lambda x: 'True' if x == 1 else 'False')
        
        predictions_df.to_csv(save_path, index=False)

    def plot_and_evaluate(self, predictions_df, annotations_df, save_path):
        plot_predictions(predictions_df, annotations_df, save_path)
        classification_metrics(predictions_df, annotations_df, save_path)
        regression_metrics(predictions_df, annotations_df, save_path)

'''
################################# new version ########################################
import os
import torch
import pandas as pd
import numpy as np
from utils import plot_predictions, classification_metrics, regression_metrics

class Evaluator:
    def __init__(self, model, device):
        self.model = model
        self.device = device

    def evaluate(self, dataloader):
        self.model.eval()
        predictions = []
        with torch.no_grad():
            for features, _ in dataloader:
                features = features.to(self.device)
                outputs_regression, outputs_classification = self.model(features)

                # Move outputs to CPU and convert to numpy arrays
                outputs_regression = outputs_regression.cpu().numpy()
                outputs_classification = torch.sigmoid(outputs_classification).cpu().numpy()  # Apply sigmoid to classification outputs

                # Convert classification probabilities to binary (0/1) values
                outputs_classification_binary = (outputs_classification > 0.5).astype(int)

                # Combine regression and classification outputs
                outputs_combined = np.concatenate((outputs_regression, outputs_classification_binary), axis=1)
                predictions.append(outputs_combined)

        # Concatenate all predictions into a single array
        predictions = np.concatenate(predictions, axis=0)
        return predictions

    def save_predictions(self, predictions, annotations, save_path):
        predictions_df = pd.DataFrame(predictions, columns=[
            'target_speed', 'rel_angle', 'lateral_distance', 'distance', 
            'brake', 'junction', 'vehicle_hazard', 'light_hazard', 'walker_hazard', 'stop_sign_hazard'
        ])
        
        # Convert classification values to 'True'/'False'
        for col in ['brake', 'junction', 'vehicle_hazard', 'light_hazard', 'walker_hazard', 'stop_sign_hazard']:
            predictions_df[col] = predictions_df[col].apply(lambda x: 'True' if x == 1 else 'False')
        
        predictions_df.to_csv(save_path, index=False)
        print(f'Predictions saved to {save_path}')

    def plot_and_evaluate(self, predictions_df, annotations_df, save_path):
        # Plot predictions
        plot_predictions(predictions_df, annotations_df, save_path)

        # Evaluate classification metrics
        classification_metrics(predictions_df, annotations_df, save_path)

        # Evaluate regression metrics
        regression_metrics(predictions_df, annotations_df, save_path)
