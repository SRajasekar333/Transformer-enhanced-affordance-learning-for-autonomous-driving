'''
########### old method ########################
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
import matplotlib.pyplot as plt

class Trainer:
    def __init__(self, model, device, dataloader, lr=1e-4, epochs=100, save_path='/data/horse/ws/rasa397c-Sankar/Multimodal/transfuser/model_ckpt/job_fused_features_setting2_2workers_BS100_GPU8/output_old'):
        self.model = model
        self.device = device
        self.dataloader = dataloader
        self.lr = lr
        self.epochs = epochs
        #self.criterion = nn.MSELoss()
        self.criterion_regression = nn.MSELoss()
        self.criterion_classification = nn.BCEWithLogitsLoss()  # Use this for binary classification
        self.optimizer = optim.Adam(self.model.parameters(), lr=self.lr)
        self.train_losses = []
        self.save_path = save_path

    def train(self):
        self.model.train()
        for epoch in range(self.epochs):
            running_loss = 0.0
            for features, annotations in self.dataloader:
                features = features.to(self.device)
                annotations = annotations.to(self.device, dtype=torch.float32)
                #print(f'Annotations shape: {annotations.shape}')

                self.optimizer.zero_grad()
                outputs = self.model(features)

                #print(f'Outputs shape: {outputs.shape}')
                
                # Separate outputs and annotations for regression and classification
                #outputs_regression = outputs[:, [0, 7, 8, 9]]  # First and last three for regression
                #outputs_classification = outputs[:, 1:7]  # The rest are classification
                #annotations_regression = annotations[:, [2, 8, 9, 10]]
                #annotations_classification = annotations[:, 3:9]
                
                # Assuming the outputs and annotations are structured accordingly
                try:
                    outputs_regression = outputs[:, [0, 7, 8, 9]]  # Columns: target_speed, rel_angle, lateral_distance, distance
                    outputs_classification = outputs[:, 1:7]  # Columns: brake, junction, vehicle_hazard, light_hazard, walker_hazard, stop_sign_hazard

                    annotations_regression = annotations[:, [0, 7, 8, 9]]
                    annotations_classification = annotations[:, 1:7]
                except IndexError as e:
                    print(f'IndexError: {e}')
                    print(f'Outputs shape: {outputs.shape}')
                    print(f'Annotations shape: {annotations.shape}')
                    raise

                loss_regression = self.criterion_regression(outputs_regression, annotations_regression)
                loss_classification = self.criterion_classification(outputs_classification, annotations_classification)

                loss = loss_regression + loss_classification
                loss.backward()
                self.optimizer.step()
                running_loss += loss.item()

                
                #loss = self.criterion(outputs, annotations)
                #loss.backward()
                #self.optimizer.step()
                #running_loss += loss.item()
                
            ###    
            avg_loss = running_loss / len(self.dataloader)
            self.train_losses.append(avg_loss)
            ###
            print(f'Epoch [{epoch+1}/{self.epochs}], Loss: {running_loss/len(self.dataloader):.4f}')
        print('Training complete')
        ###
        self.plot_metrics()
        ###

    def save_model(self, save_path):
        torch.save(self.model.state_dict(), save_path)

    ###
    def plot_metrics(self):
        epochs = range(1, self.epochs + 1)
        plt.figure(figsize=(10, 5))

        # Plot training loss
        plt.subplot(1, 1, 1)
        plt.plot(epochs, self.train_losses, 'bo-', label='Train Loss')
        plt.xlabel('Epochs')
        plt.ylabel('Loss')
        plt.title('Training Loss Over Epochs')
        plt.legend()
        
        # Save the plot
        plt.grid(True)
        if self.save_path:
            plt.savefig(f'{self.save_path}/training_loss_plot.png')
            print(f'Training loss plot saved to {self.save_path}/training_loss_plot.png')
        plt.close()
    ###

'''
###################### new method ####################
import torch
import torch.nn as nn
import torch.optim as optim
import matplotlib.pyplot as plt
#from torch.utils.data import DataLoader #weight

class Trainer:
    def __init__(self, model, device, dataloader, lr=1e-4, epochs=200, save_path='/data/horse/ws/rasa397c-Sankar/Multimodal/transfuser/model_ckpt/trans_preddata/output'):
        self.model = model
        self.device = device
        self.dataloader = dataloader
        self.lr = lr
        self.epochs = epochs
        self.criterion_regression = nn.MSELoss()
        self.criterion_classification = nn.BCEWithLogitsLoss()  # For binary classification with logits
        self.optimizer = optim.Adam(self.model.parameters(), lr=self.lr)
        self.train_losses = []
        self.save_path = save_path

    def train(self):
        self.model.train()

        # Initialize model weights
        self.model.apply(self.init_weights) #weight
        
        for epoch in range(self.epochs):
            running_loss = 0.0
            for features, annotations in self.dataloader:
                features = features.to(self.device)
                annotations = annotations.to(self.device, dtype=torch.float32)

                self.optimizer.zero_grad()
                outputs_regression, outputs_classification = self.model(features)

                # Separate the annotations for regression and classification
                annotations_regression = annotations[:, [0, 7, 8, 9]]  # Adjust these indices based on your dataset
                annotations_classification = annotations[:, 1:7]

                # Calculate the losses
                loss_regression = self.criterion_regression(outputs_regression, annotations_regression)
                loss_classification = self.criterion_classification(outputs_classification, annotations_classification)

                # Total loss
                loss = loss_regression + loss_classification
                loss.backward()

                # Gradient clipping
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0) #weight
                
                self.optimizer.step()
                running_loss += loss.item()

            avg_loss = running_loss / len(self.dataloader)
            self.train_losses.append(avg_loss)

            print(f'Epoch [{epoch+1}/{self.epochs}], Loss: {avg_loss:.4f}')
        
        print('Training complete')
        self.plot_metrics()

    def save_model(self, save_path):
        torch.save(self.model.state_dict(), save_path)

    def plot_metrics(self):
        epochs = range(1, self.epochs + 1)
        plt.figure(figsize=(10, 5))

        # Plot training loss
        plt.plot(epochs, self.train_losses, 'bo-', label='Train Loss')
        plt.xlabel('Epochs')
        plt.ylabel('Loss')
        plt.title('Training Loss Over Epochs')
        plt.legend()
        
        # Save the plot
        plt.grid(True)
        if self.save_path:
            plt.savefig(f'{self.save_path}/training_loss_plot.png')
            print(f'Training loss plot saved to {self.save_path}/training_loss_plot.png')
        plt.close()
    
    ###weight
    @staticmethod
    def init_weights(m):
        if isinstance(m, nn.Linear):
            torch.nn.init.xavier_uniform_(m.weight)
            if m.bias is not None:
                m.bias.data.fill_(0.01)
    


######## old tries #####################################################################################################
'''
# try for training and valodation loss and accuracy
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
import matplotlib.pyplot as plt

class Trainer:
    def __init__(self, model, device, train_loader, val_loader, lr=1e-3, epochs=10):
        self.model = model
        self.device = device
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.lr = lr
        self.epochs = epochs
        self.criterion = nn.BCEWithLogitsLoss()
        self.optimizer = optim.Adam(self.model.parameters(), lr=self.lr)

    def train(self):
        train_losses = []
        train_accuracies = []
        val_losses = []
        val_accuracies = []

        for epoch in range(self.epochs):
            self.model.train()
            running_loss = 0.0
            correct_predictions = 0
            total_predictions = 0

            for features, annotations in self.train_loader:
                features = features.to(self.device)
                annotations = annotations.to(self.device)
                self.optimizer.zero_grad()
                outputs = self.model(features)
                loss = self.criterion(outputs, annotations)
                loss.backward()
                self.optimizer.step()
                running_loss += loss.item() * features.size(0)

                predicted = (torch.sigmoid(outputs) > 0.5).float()
                correct_predictions += (predicted == annotations).sum().item()
                total_predictions += annotations.numel()

            epoch_train_loss = running_loss / len(self.train_loader.dataset)
            epoch_train_accuracy = correct_predictions / total_predictions
            train_losses.append(epoch_train_loss)
            train_accuracies.append(epoch_train_accuracy)

            val_loss, val_accuracy = self.validate()
            val_losses.append(val_loss)
            val_accuracies.append(val_accuracy)

            print(f'Epoch {epoch + 1}/{self.epochs}, Train Loss: {epoch_train_loss:.4f}, Train Accuracy: {epoch_train_accuracy:.4f}, Val Loss: {val_loss:.4f}, Val Accuracy: {val_accuracy:.4f}')

        self.plot_metrics(train_losses, train_accuracies, val_losses, val_accuracies)

    def validate(self):
        self.model.eval()
        running_loss = 0.0
        correct_predictions = 0
        total_predictions = 0

        with torch.no_grad():
            for features, annotations in self.val_loader:
                features = features.to(self.device)
                annotations = annotations.to(self.device)
                outputs = self.model(features)
                loss = self.criterion(outputs, annotations)
                running_loss += loss.item() * features.size(0)

                predicted = (torch.sigmoid(outputs) > 0.5).float()
                correct_predictions += (predicted == annotations).sum().item()
                total_predictions += annotations.numel()

        epoch_val_loss = running_loss / len(self.val_loader.dataset)
        epoch_val_accuracy = correct_predictions / total_predictions
        return epoch_val_loss, epoch_val_accuracy

    def plot_metrics(self, train_losses, train_accuracies, val_losses, val_accuracies):
        epochs = range(1, self.epochs + 1)

        plt.figure(figsize=(12, 6))
        plt.subplot(1, 2, 1)
        plt.plot(epochs, train_losses, label='Train Loss')
        plt.plot(epochs, val_losses, label='Val Loss')
        plt.xlabel('Epochs')
        plt.ylabel('Loss')
        plt.title('Loss Over Epochs')
        plt.legend()

        plt.subplot(1, 2, 2)
        plt.plot(epochs, train_accuracies, label='Train Accuracy')
        plt.plot(epochs, val_accuracies, label='Val Accuracy')
        plt.xlabel('Epochs')
        plt.ylabel('Accuracy')
        plt.title('Accuracy Over Epochs')
        plt.legend()

        plt.tight_layout()
        plt.savefig('training_validation_metrics.png')
        plt.close()

    def save_model(self, save_path):
        torch.save(self.model.state_dict(), save_path)
'''