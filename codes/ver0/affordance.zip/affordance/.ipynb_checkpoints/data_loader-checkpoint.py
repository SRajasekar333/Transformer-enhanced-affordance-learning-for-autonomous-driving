'''
import os
import torch
import csv

class DataLoader:
    def __init__(self, root_dir, batch_size):
        self.root_dir = root_dir
        self.batch_size = batch_size

    def load_features(self, features_path):
        return torch.load(features_path)

    def load_annotations(self, csv_file_path):
        annotations = []
        with open(csv_file_path, mode='r') as csv_file:
            csv_reader = csv.reader(csv_file)
            headers = next(csv_reader)
            for row in csv_reader:
                annotations.append(dict(zip(headers, row)))
        return annotations

    def get_feature_paths(self, annotations):
        features = []
        for annotation in annotations:
            batch_idx = annotation['batch']
            sample_idx = annotation['idx']
            features_path = os.path.join(self.root_dir, f'batch_{batch_idx}_idx_{sample_idx}.pth')
            features.append(features_path)
        return features

    def load_data(self, features_paths):
        return [self.load_features(path) for path in features_paths]
'''
'''
import os
import pandas as pd
import torch
from torch.utils.data import Dataset, DataLoader

class CARLA_Data(Dataset):
    def __init__(self, features_paths, annotations):
        self.features_paths = features_paths
        self.annotations = annotations

    def __len__(self):
        return len(self.features_paths)

    def __getitem__(self, idx):
        features = torch.load(self.features_paths[idx])
        annotation = self.annotations.iloc[idx]
        target_speed = annotation['target_speed']
        brake = annotation['brake']
        junction = annotation['junction']
        vehicle_hazard = annotation['vehicle_hazard']
        light_hazard = annotation['light_hazard']
        walker_hazard = annotation['walker_hazard']
        stop_sign_hazard = annotation['stop_sign_hazard']
        return features, torch.tensor([target_speed, brake, junction, vehicle_hazard, light_hazard, walker_hazard, stop_sign_hazard], dtype=torch.float32)

class DataLoaderWrapper:
    def __init__(self, root_dir, batch_size):
        self.root_dir = root_dir
        self.batch_size = batch_size

    def load_annotations(self, annotations_path):
        return pd.read_csv(annotations_path)

    def get_feature_paths(self, annotations):
        feature_paths = [os.path.join(self.root_dir, f'batch_{row.batch}_idx_{row.idx}.pt') for _, row in annotations.iterrows()]
        return feature_paths

    def create_dataloader(self, features_paths, annotations):
        dataset = CARLA_Data(features_paths, annotations)
        return DataLoader(dataset, batch_size=self.batch_size, shuffle=True, num_workers=2, collate_fn=self.custom_collate)

    def custom_collate(self, batch):
        features = torch.stack([item[0] for item in batch])
        annotations = torch.stack([item[1] for item in batch])
        return features, annotations
'''


import os
import pandas as pd
import torch
from torch.utils.data import Dataset, DataLoader, random_split

class CARLA_Data(Dataset):
    def __init__(self, features_paths, annotations):
        self.features_paths = features_paths
        self.annotations = annotations

    def __len__(self):
        return len(self.features_paths)

    def __getitem__(self, idx):
        features = torch.load(self.features_paths[idx])
        annotation = self.annotations.iloc[idx]
        target_speed = annotation['target_speed']
        brake = annotation['brake']
        junction = annotation['junction']
        vehicle_hazard = annotation['vehicle_hazard']
        light_hazard = annotation['light_hazard']
        walker_hazard = annotation['walker_hazard']
        stop_sign_hazard = annotation['stop_sign_hazard']
        rel_angle = annotation['rel_angle']
        lateral_distance = annotation['lateral_distance']
        distance = annotation['distance']
        return features, torch.tensor([target_speed, brake, junction, vehicle_hazard, light_hazard, walker_hazard, stop_sign_hazard, rel_angle, lateral_distance, distance], dtype=torch.float32)

class DataLoaderWrapper:
    def __init__(self, root_dir, batch_size):
        self.root_dir = root_dir
        self.batch_size = batch_size

    def load_annotations(self, annotations_path):
        return pd.read_csv(annotations_path)

    def get_feature_paths(self, annotations):
        feature_paths = [os.path.join(self.root_dir, f'batch_{row.batch}_idx_{row.idx}.pt') for _, row in annotations.iterrows()]
        return feature_paths

    def create_dataloader(self, features_paths, annotations):
        dataset = CARLA_Data(features_paths, annotations)
        return DataLoader(dataset, batch_size=self.batch_size, shuffle=False, num_workers=2, collate_fn=self.custom_collate)

    def custom_collate(self, batch):
        features = torch.stack([item[0] for item in batch])
        annotations = torch.stack([item[1] for item in batch])
        return features, annotations

'''
import os
import pandas as pd
import torch
from torch.utils.data import Dataset, DataLoader, random_split

class CARLAData(Dataset):
    def __init__(self, features_paths, annotations):
        self.features_paths = features_paths
        self.annotations = annotations

    def __len__(self):
        return len(self.features_paths)

    def __getitem__(self, idx):
        features = torch.load(self.features_paths[idx])
        annotations = self.annotations.iloc[idx, 2:].values.astype(float)
        return torch.tensor(features), torch.tensor(annotations)

class DataLoaderWrapper:
    def __init__(self, root_dir, batch_size):
        self.root_dir = root_dir
        self.batch_size = batch_size

    def load_annotations(self, annotations_path):
        return pd.read_csv(annotations_path)

    def get_feature_paths(self, annotations):
        return [os.path.join(self.root_dir, f'batch_{row["batch"]}_idx_{row["idx"]}.pt') for _, row in annotations.iterrows()]

    def create_train_val_dataloaders(self, features_paths, annotations, val_split=0.2):
        dataset = CARLAData(features_paths, annotations)
        val_size = int(len(dataset) * val_split)
        train_size = len(dataset) - val_size
        train_dataset, val_dataset = random_split(dataset, [train_size, val_size])

        train_loader = DataLoader(train_dataset, batch_size=self.batch_size, shuffle=True, num_workers=4, pin_memory=True)
        val_loader = DataLoader(val_dataset, batch_size=self.batch_size, shuffle=False, num_workers=4, pin_memory=True)

        return train_loader, val_loader
'''