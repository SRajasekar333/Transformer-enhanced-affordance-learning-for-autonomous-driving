import os
import pandas as pd
import torch
from torch.utils.data import Dataset, DataLoader

class CARLA_Data(Dataset):
    def __init__(self, features_paths, annotations):
        self.features_paths = features_paths
        self.annotations = annotations

    def __len__(self):
        return len(self.features_paths)

    def __getitem__(self, idx):
        features = torch.load(self.features_paths[idx])
        annotation = self.annotations.iloc[idx]
        target_speed = annotation['target_speed']
        brake = annotation['brake']
        junction = annotation['junction']
        vehicle_hazard = annotation['vehicle_hazard']
        light_hazard = annotation['light_hazard']
        walker_hazard = annotation['walker_hazard']
        stop_sign_hazard = annotation['stop_sign_hazard']
        rel_angle = annotation['rel_angle']
        lateral_distance = annotation['lateral_distance']
        distance = annotation['distance']
        return features, torch.tensor([target_speed, brake, junction, vehicle_hazard, light_hazard, walker_hazard, stop_sign_hazard, rel_angle, lateral_distance, distance], dtype=torch.float32)

class DataLoaderWrapper:
    def __init__(self, root_dir, batch_size):
        self.root_dir = root_dir
        self.batch_size = batch_size

    def load_annotations(self, annotations_path):
        return pd.read_csv(annotations_path)

    def get_feature_paths(self, annotations):
        feature_paths = [os.path.join(self.root_dir, f'batch_{row.batch}_idx_{row.idx}.pt') for _, row in annotations.iterrows()]
        return feature_paths

    def create_dataloader(self, features_paths, annotations):
        dataset = CARLA_Data(features_paths, annotations)
        return DataLoader(dataset, batch_size=self.batch_size, shuffle=False, num_workers=2, collate_fn=self.custom_collate)

    def custom_collate(self, batch):
        features = torch.stack([item[0] for item in batch])
        annotations = torch.stack([item[1] for item in batch])
        return features, annotations
