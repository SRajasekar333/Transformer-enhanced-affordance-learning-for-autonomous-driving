import os
import torch
import numpy as np
import pandas as pd
from sklearn.model_selection import ParameterGrid
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score, accuracy_score, precision_score, recall_score, f1_score
from model1 import AffordancePredictor
from data_loader1 import DataLoaderWrapper
from evaluator1 import Evaluator

def load_model(model_path, input_dim, hidden_dim, num_regression_outputs, num_classification_outputs, device='cuda'):
    model = AffordancePredictor(input_dim, hidden_dim, num_regression_outputs, num_classification_outputs)
    state_dict = torch.load(model_path, map_location=device)
    model.load_state_dict(state_dict, strict=False)  # Set strict=False to ignore size mismatches
    model.to(device)
    model.eval()  # Set the model to evaluation mode
    return model

def evaluate_model(model, dataloader, device='cuda'):
    model.eval()
    predictions = []
    true_labels = []

    with torch.no_grad():
        for features, labels in dataloader:
            features = features.to(device)
            labels = labels.to(device)

            outputs = model(features)
            predictions.append(outputs.cpu().numpy())
            true_labels.append(labels.cpu().numpy())

    predictions = np.concatenate(predictions, axis=0)
    true_labels = np.concatenate(true_labels, axis=0)

    return predictions, true_labels

def hyperparameter_optimization(model_path, param_grid, validation_loader, input_dim, num_regression_outputs, num_classification_outputs, device='cuda'):
    best_params = None
    best_score = float('inf')  # assuming lower is better
    results = []

    for params in ParameterGrid(param_grid):
        print(f"Testing parameters: {params}")
        
        # Load model with the current set of parameters
        model = load_model(model_path, input_dim, params['hidden_dim'], num_regression_outputs, num_classification_outputs, device)
        
        # Evaluate model
        predictions, true_labels = evaluate_model(model, validation_loader, device)
        
        # Compute validation score
        mse = mean_squared_error(true_labels[:, :num_regression_outputs], predictions[:, :num_regression_outputs])
        results.append((params, mse))
        
        if mse < best_score:
            best_score = mse
            best_params = params

    print(f"Best hyperparameters: {best_params}")
    print(f"Best validation MSE: {best_score}")
    
    return best_params, results

def main():
    # Paths and settings
    root_dir = '/data/horse/ws/rasa397c-Sankar/Multimodal/transfuser/model_ckpt/fullafford_valdata1_transfuser1'  # Update this path
    annotations_path = os.path.join(root_dir, 'annotations_valdata.csv')
    model_path = '/data/horse/ws/rasa397c-Sankar/Multimodal/transfuser/model_ckpt/valuation_tf_train_val/model_new.pth'  # Update this path
    output_dir = '/data/horse/ws/rasa397c-Sankar/Multimodal/transfuser/model_ckpt/valuation_tf_train_val/output_hyper'  # Update this path
    device = 'cuda' if torch.cuda.is_available() else 'cpu'

    # Ensure the output directory exists
    os.makedirs(output_dir, exist_ok=True)

    # Model parameters
    input_dim = 512
    num_regression_outputs = 4
    num_classification_outputs = 6

    # Data loading
    batch_size = 32  # Initial batch size, can be optimized
    data_loader_wrapper = DataLoaderWrapper(root_dir=root_dir, batch_size=batch_size)
    annotations = data_loader_wrapper.load_annotations(annotations_path)
    features_paths = data_loader_wrapper.get_feature_paths(annotations)
    validation_loader = data_loader_wrapper.create_dataloader(features_paths, annotations)

    # Define hyperparameter grid
    param_grid = {
        'hidden_dim': [64, 128, 256, 512],  # Example hyperparameters to search over
        'learning_rate': [0.001, 0.01, 0.1],
        'batch_size': [16, 32, 64]
    }

    # Perform hyperparameter optimization
    best_params, _ = hyperparameter_optimization(model_path, param_grid, validation_loader, input_dim, num_regression_outputs, num_classification_outputs, device)

    # Load test data
    test_root_dir = '/data/horse/ws/rasa397c-Sankar/Multimodal/transfuser/model_ckpt/trans_preddata'  # Update with your test data path
    test_annotations_path = os.path.join(test_root_dir, 'annotations_trans_preddata.csv')

    # Load test data with the optimized batch size
    data_loader_wrapper = DataLoaderWrapper(root_dir=test_root_dir, batch_size=best_params['batch_size'])
    test_annotations = data_loader_wrapper.load_annotations(test_annotations_path)
    test_features_paths = data_loader_wrapper.get_feature_paths(test_annotations)
    test_loader = data_loader_wrapper.create_dataloader(test_features_paths, test_annotations)

    # Load the best model
    model = load_model(model_path, input_dim, best_params['hidden_dim'], num_regression_outputs, num_classification_outputs, device)

    # Evaluate on the test set
    predictions, true_labels = evaluate_model(model, test_loader, device)

    # Compute regression metrics
    mse = mean_squared_error(true_labels[:, :num_regression_outputs], predictions[:, :num_regression_outputs])
    mae = mean_absolute_error(true_labels[:, :num_regression_outputs], predictions[:, :num_regression_outputs])
    r2 = r2_score(true_labels[:, :num_regression_outputs], predictions[:, :num_regression_outputs])
    print(f'Test Set Regression Metrics: MSE={mse:.4f}, MAE={mae:.4f}, R2={r2:.4f}')

    # Compute classification metrics
    for i, label in enumerate(['brake', 'junction', 'vehicle_hazard', 'light_hazard', 'walker_hazard', 'stop_sign_hazard']):
        y_true = true_labels[:, num_regression_outputs + i]
        y_pred = (predictions[:, num_regression_outputs + i] > 0.5).astype(int)  # Convert probabilities to binary labels

        accuracy = accuracy_score(y_true, y_pred)
        precision = precision_score(y_true, y_pred, zero_division=1)
        recall = recall_score(y_true, y_pred, zero_division=1)
        f1 = f1_score(y_true, y_pred, zero_division=1)
        print(f'{label.capitalize()} Metrics: Accuracy={accuracy:.4f}, Precision={precision:.4f}, Recall={recall:.4f}, F1-Score={f1:.4f}')

if __name__ == '__main__':
    main()
