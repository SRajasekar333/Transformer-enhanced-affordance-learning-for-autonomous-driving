'''
import matplotlib
matplotlib.use('Agg')  # Use the Agg backend for rendering plots in a headless environment
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from sklearn.metrics import classification_report, confusion_matrix, mean_squared_error, r2_score

def plot_predictions(predictions, annotations, output_dir):
    metrics = ['target_speed', 'brake', 'junction', 'vehicle_hazard', 'light_hazard', 'walker_hazard', 'stop_sign_hazard', 'rel_angle', 'lateral_distance', 'distance']
    
    for metric in metrics:
        plt.figure(figsize=(10, 6))
        plt.plot(predictions[metric], label='Predicted')
        plt.plot(annotations[metric], label='Actual')
        plt.xlabel('Sample Index')
        plt.ylabel(metric)
        plt.title(f'Predicted vs Actual {metric}')
        plt.legend()
        plt.savefig(f'{output_dir}/{metric}_comparison.png')
        plt.close()

def classification_metrics(predictions, annotations, output_dir):
    metrics = ['brake', 'junction', 'vehicle_hazard', 'light_hazard', 'walker_hazard', 'stop_sign_hazard']
    for metric in metrics:
        if annotations[metric].nunique() <= 2:  # Ensure the target is binary
            report = classification_report(annotations[metric], predictions[metric].round(), output_dict=True)
            print(f'Classification Report for {metric}:\n', report)
            
            cm = confusion_matrix(annotations[metric], predictions[metric].round())
            plt.figure(figsize=(10, 6))
            plt.imshow(cm, interpolation='nearest', cmap=plt.cm.Blues)
            plt.title(f'Confusion Matrix for {metric}')
            plt.colorbar()
            plt.ylabel('True label')
            plt.xlabel('Predicted label')
            plt.savefig(f'{output_dir}/{metric}_confusion_matrix.png')
            plt.close()
            
def regression_metrics(predictions, annotations, output_dir):
    metrics = ['target_speed', 'rel_angle', 'lateral_distance', 'distance']
    for metric in metrics:
        mse = mean_squared_error(annotations[metric], predictions[metric])
        r2 = r2_score(annotations[metric], predictions[metric])
        print(f'{metric} - Mean Squared Error: {mse}, R^2 Score: {r2}')
        
        plt.figure(figsize=(10, 6))
        plt.scatter(annotations[metric], predictions[metric], alpha=0.5)
        plt.xlabel('Actual')
        plt.ylabel('Predicted')
        plt.title(f'Predicted vs Actual {metric}')
        plt.savefig(f'{output_dir}/{metric}_scatter.png')
        plt.close()

'''
import matplotlib
matplotlib.use('Agg')  # Use the Agg backend for rendering plots in a headless environment
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from sklearn.metrics import classification_report, confusion_matrix, mean_squared_error, r2_score, f1_score, precision_score, recall_score

def plot_predictions(predictions, annotations, output_dir):
    metrics = ['target_speed', 'brake', 'junction', 'vehicle_hazard', 'light_hazard', 'walker_hazard', 'stop_sign_hazard', 'rel_angle', 'lateral_distance', 'distance']
    
    for metric in metrics:
        plt.figure(figsize=(10, 6))
        plt.plot(predictions[metric], label='Predicted')
        plt.plot(annotations[metric], label='Actual')
        plt.xlabel('Sample Index')
        plt.ylabel(metric)
        plt.title(f'Predicted vs Actual {metric}')
        plt.legend()
        plt.savefig(f'{output_dir}/{metric}_comparison.png')
        plt.close()

def classification_metrics(predictions, annotations, output_dir):
    metrics = ['brake', 'junction', 'vehicle_hazard', 'light_hazard', 'walker_hazard', 'stop_sign_hazard']
    for metric in metrics:
        if annotations[metric].nunique() <= 2:  # Ensure the target is binary
            y_true = annotations[metric]
            y_pred = predictions[metric].round()
            report = classification_report(y_true, y_pred, output_dict=True)
            print(f'Classification Report for {metric}:\n', report)

            cm = confusion_matrix(y_true, y_pred)
            plt.figure(figsize=(10, 6))
            plt.imshow(cm, interpolation='nearest', cmap=plt.cm.Blues)
            plt.title(f'Confusion Matrix for {metric}')
            plt.colorbar()
            plt.ylabel('True label')
            plt.xlabel('Predicted label')
            plt.savefig(f'{output_dir}/{metric}_confusion_matrix.png')
            plt.close()
            
            # Calculate and print F1 score, precision, and recall
            f1 = f1_score(y_true, y_pred)
            precision = precision_score(y_true, y_pred)
            recall = recall_score(y_true, y_pred)
            print(f'{metric} - F1 Score: {f1}, Precision: {precision}, Recall: {recall}')

def regression_metrics(predictions, annotations, output_dir):
    metrics = ['target_speed', 'rel_angle', 'lateral_distance', 'distance']
    for metric in metrics:
        mse = mean_squared_error(annotations[metric], predictions[metric])
        r2 = r2_score(annotations[metric], predictions[metric])
        print(f'{metric} - Mean Squared Error: {mse}, R^2 Score: {r2}')
        
        plt.figure(figsize=(10, 6))
        plt.scatter(annotations[metric], predictions[metric], alpha=0.5)
        plt.xlabel('Actual')
        plt.ylabel('Predicted')
        plt.title(f'Predicted vs Actual {metric}')
        plt.savefig(f'{output_dir}/{metric}_scatter.png')
        plt.close()
