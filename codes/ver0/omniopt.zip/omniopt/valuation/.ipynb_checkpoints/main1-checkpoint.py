import os
import torch
import pandas as pd
from model1 import AffordancePredictor
from data_loader1 import DataLoaderWrapper
from evaluator1 import Evaluator

def load_model(model_path, input_dim, hidden_dim, num_regression_outputs, num_classification_outputs, device='cuda'):
    model = AffordancePredictor(input_dim, hidden_dim, num_regression_outputs, num_classification_outputs)
    model.load_state_dict(torch.load(model_path))
    model.to(device)
    model.eval()  # Set the model to evaluation mode
    return model

def main():
    # Paths and settings
    root_dir = '/data/horse/ws/rasa397c-Sankar/Multimodal/transfuser/model_ckpt/fullafford_valdata1_transfuser1'  # Update this path
    annotations_path = os.path.join(root_dir, 'annotations_valdata.csv')
    model_path = '/data/horse/ws/rasa397c-Sankar/Multimodal/transfuser/model_ckpt/valuation_tf_train_val/model_new.pth'  # Update this path
    output_dir = '/data/horse/ws/rasa397c-Sankar/Multimodal/transfuser/model_ckpt/valuation_tf_train_val/output_new'  # Update this path
    device = 'cuda' if torch.cuda.is_available() else 'cpu'

    # Ensure the output directory exists
    os.makedirs(output_dir, exist_ok=True)

    # Set the save path for predictions
    save_path = os.path.join(output_dir, 'predictions.csv')

    # Model parameters
    input_dim = 512
    hidden_dim = 256
    #output_dim = 10
    num_regression_outputs = 4  # Number of regression outputs
    num_classification_outputs = 6  # Number of classification outputs

    # Load model
    model = load_model(model_path, input_dim, hidden_dim, num_regression_outputs, num_classification_outputs, device)

    # Data loading
    batch_size = 100  # Adjust batch size based on your hardware capabilities
    data_loader_wrapper = DataLoaderWrapper(root_dir=root_dir, batch_size=batch_size)
    annotations = data_loader_wrapper.load_annotations(annotations_path)
    features_paths = data_loader_wrapper.get_feature_paths(annotations)
    dataloader = data_loader_wrapper.create_dataloader(features_paths, annotations)

    # Evaluator setup
    evaluator = Evaluator(model, device)

    # Perform evaluation
    predictions = evaluator.evaluate(dataloader)
    evaluator.save_predictions(predictions, annotations, save_path)

    # Drop 'batch' and 'idx' columns from annotations for evaluation
    annotations_df = annotations.drop(columns=['batch', 'idx'])

    # Load predictions as DataFrame
    predictions_df = pd.DataFrame(predictions, columns=[
        'target_speed', 'rel_angle', 'lateral_distance', 'distance',
        'brake', 'junction', 'vehicle_hazard', 'light_hazard', 'walker_hazard', 'stop_sign_hazard'
    ])

    # Evaluate and plot results
    evaluator.plot_and_evaluate(predictions_df, annotations_df, output_dir)

if __name__ == '__main__':
    main()
