#!/bin/bash -l
# ^ Shebang-Line, so that it is known that this is a bash file
# -l means 'load this as login shell', so that /etc/profile gets loaded and you can use 'module load' or 'ml' as usual

# If you don't use this script via `./run.sh' or just `srun run.sh', but like `srun bash run.sh', please add the '-l' there too.
# Like this:
# srun bash -l run.sh

# Load modules your program needs, always specify versions!

module load release/23.04 Anaconda3
source $EBROOTANACONDA3/etc/profile.d/conda.sh
conda activate transCAL

python3 /data/horse/ws/rasa397c-Sankar/Multimodal/transfuser/model_ckpt/omniopt/valuation/omni.py $*